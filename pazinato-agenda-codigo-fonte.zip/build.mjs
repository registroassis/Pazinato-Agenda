// Gera a pasta dist/ (site estático pronto para GitHub Pages / Firebase Hosting).
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';

const VERSAO = new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '');
const dist = 'dist';
fs.rmSync(dist, { recursive: true, force: true });
fs.cpSync('public', dist, { recursive: true });

await esbuild.build({
  entryPoints: ['src/main.js'], bundle: true, splitting: true, format: 'esm', outdir: `${dist}/app`,
  minify: true, target: ['es2020', 'safari15'], chunkNames: 'chunks/[name]-[hash]', legalComments: 'none',
});

const idx = path.join(dist, 'index.html');
fs.writeFileSync(idx, fs.readFileSync(idx, 'utf8').replaceAll('__VERSAO__', VERSAO));

const arquivos = [];
(function walk(d) {
  for (const f of fs.readdirSync(d)) {
    const p = path.join(d, f);
    if (fs.statSync(p).isDirectory()) walk(p); else arquivos.push(path.relative(dist, p).split(path.sep).join('/'));
  }
})(dist);
const precache = ['./', ...arquivos.filter((f) => !f.endsWith('.map'))];
fs.writeFileSync(path.join(dist, 'sw.js'), fs.readFileSync('sw.template.js', 'utf8')
  .replace('__VERSAO__', VERSAO).replace('__ARQUIVOS__', JSON.stringify(precache)));
fs.copyFileSync('firestore.rules', path.join(dist, 'firestore.rules.txt'));
fs.writeFileSync(path.join(dist, '.nojekyll'), '');
console.log('versão', VERSAO, '—', arquivos.length, 'arquivos');
