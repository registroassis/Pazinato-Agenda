# Pazinato · Agenda e Ordens de Serviço: guia de instalação e manual de uso

App de agenda compartilhada e ordens de serviço da **Pazinato Climatização Automotiva** para Danilo e Juninho. É um PWA: funciona no navegador do computador e pode ser instalado na tela inicial do iPhone e do Android. Os dados ficam no **Firebase** (Google): login com e-mail e senha, banco **Firestore** com sincronização em tempo real.

**Login único:** a empresa tem um só e-mail e senha. Ao entrar, a pessoa toca no próprio nome (**Danilo** ou **Juninho**), e tudo o que ela lançar ou alterar fica registrado nesse nome.

---

## 1. Colocar no ar (feito uma vez, cerca de 20 minutos)

### 1.1 Criar o projeto Firebase
1. Acesse https://console.firebase.google.com e clique em **Adicionar projeto**. Sugestão de nome: `pazinato-agenda`. Pode desativar o Google Analytics.
2. Menu **Build → Authentication → Começar**. Ative o provedor **E-mail/senha**.
3. Em **Authentication → Users → Adicionar usuário**, crie **um único login** para a empresa (ex.: `agenda@pazinato.com.br` e uma senha forte). Os dois usam esse mesmo login.
4. (Recomendado) Em **Authentication → Settings → Ações do usuário**, desmarque **"Ativar criação (inscrição)"**.
5. Menu **Build → Firestore Database → Criar banco de dados**. Escolha a localização **southamerica-east1 (São Paulo)** e o **modo de produção**.
6. Em **Firestore → Regras**, apague o conteúdo e cole todo o arquivo `firestore.rules.txt` deste pacote. **Troque `agenda@pazinato.com.br` pelo e-mail criado no passo 3** (em minúsculas) e clique em **Publicar**.
7. Em **Configurações do projeto (engrenagem) → Seus apps → Web (`</>`)**, registre o app (ex.: "Pazinato Agenda"). Copie os valores de `firebaseConfig` (apiKey, authDomain, projectId, storageBucket, messagingSenderId, appId).

### 1.2 Publicar o site (GitHub Pages)
1. No GitHub, crie um repositório novo e **público** (ex.: `pazinato-agenda`).
2. **Adicionar arquivo → Carregar arquivos**: envie **todo o conteúdo** do `pazinato-agenda-site.zip` (index.html, config.js, sw.js, styles.css, manifest.webmanifest, as pastas `app`, `assets` e `icons` e o arquivo `.nojekyll`). Confirme o commit.
3. **Settings → Pages → Branch: main / (root) → Save**. Em 1 a 2 minutos o link fica disponível: `https://SEU-USUARIO.github.io/pazinato-agenda/`.
4. No repositório, abra o `config.js`, clique no lápis (editar), cole os valores do Firebase no bloco `firebase` e confirme o commit.
5. No Firebase, em **Authentication → Settings → Domínios autorizados**, adicione `SEU-USUARIO.github.io`.

Pronto: abra o link, entre com o login da empresa e toque em **Danilo** ou **Juninho**. O aparelho lembra quem escolheu. Para trocar, toque no nome que aparece no topo.

> Enquanto o `config.js` não está preenchido, o app mostra "Configuração pendente" e oferece um **modo teste local** (dados só naquele navegador). Ele serve para conhecer o app. Não use para trabalho real.

## 2. Instalar no celular
- **iPhone (Safari):** abra o link → botão **Compartilhar** → **Adicionar à Tela de Início**. Abra sempre pelo ícone.
- **Android (Chrome):** abra o link → menu **⋮** → **Instalar app** (ou "Adicionar à tela inicial").
- **Computador:** use pelo navegador normalmente.

## 3. Logo, cores e nomes
- A logo da Pazinato já está aplicada no topo, no login, nos PDFs, na impressão e no ícone do celular. As cores foram tiradas da logo.
- Há duas versões da logo: `assets/logo.png` (quadrada, usada no ícone) e `assets/logo-horizontal.png` (sem fundo, usada no topo da tela inicial, no login e nos PDFs). Para trocar, substitua os arquivos mantendo os mesmos nomes (e os ícones da pasta `icons/`). As cores ficam em `cores`, no `config.js`.
- Os nomes ficam em `usuarios: ['Danilo', 'Juninho']`, no `config.js`. Para incluir alguém, acrescente o nome na lista.

## 4. Onde ficam os dados e segurança
- Tudo fica no **Cloud Firestore** do projeto Firebase (servidores do Google, região São Paulo). Coleções: `ordens`, `clientes`, `historico`, `contadores`.
- As regras só permitem acesso ao **e-mail do login da empresa**. Qualquer outra pessoa, mesmo com o link, não lê nem grava nada.
- Como o login é compartilhado, o registro de "quem fez" depende de cada um tocar no próprio nome. O app mostra sempre no topo quem está usando.
- O **histórico de auditoria** só aceita inclusões: ninguém consegue alterar ou apagar registros. Ao excluir uma OS, as regras **exigem** que uma cópia dela seja guardada no histórico.
- A numeração da OS é sequencial e única. Para continuar uma numeração antiga, ajuste `numeroInicialOS` no `config.js` **antes da primeira OS**.
- Sem internet, o app mostra os dados e aceita alterações, que sincronizam quando a conexão volta. **Criar OS nova exige internet** (para garantir o número único).
- O plano gratuito (Spark) do Firebase atende com folga.

## 5. Backup
- **No app:** Configurações → **Baixar backup completo**. Gera um Excel (OS, clientes, histórico) e um arquivo JSON com tudo. Faça **uma vez por mês** e guarde no computador ou Google Drive.
- **Automático (opcional):** no plano pago Blaze do Firebase é possível agendar backups do Firestore.

## 6. Senha
- Trocar a senha (vale para os dois): no app, em Configurações → Usuário → Alterar senha. Também pode ser feito no Firebase → Authentication.
- Se a senha vazar, troque-a. Os outros aparelhos precisarão entrar de novo.

## 7. Atualizações do app
Para instalar uma versão nova, substitua os arquivos no GitHub **exceto `config.js`**. Os celulares recebem a atualização ao reabrir o app (ou em Configurações → Verificar atualização).

---

# Manual rápido de uso

**Entrar:** use o login da empresa e toque em **Danilo** ou **Juninho**. Para trocar de pessoa, toque no nome no topo da tela.

**Navegação (barra inferior):** Início · Agenda · Ordens · Clientes · Relatórios. O botão azul **+ Nova OS** fica sempre à mão. A lupa abre a pesquisa e a engrenagem abre as Configurações.

**Início:** no topo ficam a logo, o sino de avisos (com o número de serviços atrasados) e o botão com o nome de quem está usando (toque para trocar de usuário, pesquisar, ver o histórico ou abrir as configurações). Logo abaixo aparece o **próximo atendimento** em destaque, com os contadores Agendados, Em andamento, Concluídos e Pendentes (toque em cada um para ver a lista). Depois vêm o botão **Nova Ordem de Serviço**, os **Serviços de hoje** por horário (os sem horário aparecem como "Sem horário") e os **Próximos atendimentos**. Para mudar o status, toque no selo colorido de qualquer serviço.

**Nova OS:** digite o nome do cliente. Se ele já estiver cadastrado, aparece na lista e o telefone é preenchido sozinho. Se for novo, o cadastro do cliente é criado automaticamente, sem duplicar. Só **cliente, data e status** são obrigatórios. O horário é opcional e não há bloqueio de sábados, domingos ou feriados. O número da OS e o responsável são preenchidos automaticamente.

**Alterar status:** toque no botão de status do cartão (ex.: "Agendado ▾") em qualquer lista ou agenda, ou use os três botões da ficha da OS. Ao concluir, o app registra data, hora e quem concluiu.

**Ficha da OS:** ligar, abrir o WhatsApp, abrir o mapa (quando houver endereço), editar, **duplicar** (para serviços recorrentes) e excluir (com confirmação). No fim da ficha fica o histórico completo de alterações.

**Agenda:** visão Dia, Semana ou Mês, com setas, botão "Hoje", "Ir para data" e toque no título para escolher qualquer mês e ano. O calendário mostra a quantidade de serviços e bolinhas coloridas por status. Feriados aparecem em vermelho, apenas como informação.

**Ordens (pesquisa):** busca por nº da OS, cliente, telefone, placa, veículo ou serviço. Em **Filtros** dá para combinar status, período e quem lançou.

**Clientes:** cadastro, telefone, histórico de serviços, quantidade de atendimentos, último atendimento e o botão "Nova OS" já com o cliente preenchido.

**Relatórios:** escolha o tipo (por período, agendados, em andamento, concluídos, por sócio ou resumo mensal), o período, o status, o cliente e o sócio. Toque em **Gerar** e depois em **PDF**, **Excel** ou **Imprimir**. No celular, o arquivo abre o menu de compartilhar (salvar, enviar por WhatsApp etc.).

**Histórico de alterações:** Configurações → Histórico (auditoria de tudo, com filtro por Danilo/Juninho).

**Notificações:** Configurações → Notificações (por aparelho): resumo diário, atrasados, em andamento e lembrete antes do horário. Elas funcionam com o app aberto ou usado recentemente. No iPhone, só depois de instalar na tela de início (iOS 16.4+).
