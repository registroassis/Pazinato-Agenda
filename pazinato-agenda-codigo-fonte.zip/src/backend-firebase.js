// Camada de dados real: Firebase Authentication + Cloud Firestore.
import { initializeApp } from 'firebase/app';
import {
  getAuth, onAuthStateChanged, signInWithEmailAndPassword, signOut, sendPasswordResetEmail,
  updatePassword, EmailAuthProvider, reauthenticateWithCredential, setPersistence, browserLocalPersistence,
} from 'firebase/auth';
import {
  initializeFirestore, persistentLocalCache, persistentMultipleTabManager, collection, doc, onSnapshot,
  query, where, orderBy, limit, getDocs, getDoc, runTransaction, writeBatch, serverTimestamp, setDoc, Timestamp,
} from 'firebase/firestore';
import { NOW, fmtNumOS } from './util.js';

let app, auth, db, cfg;

export const nome = 'firebase';

export async function init(config) {
  cfg = config;
  app = initializeApp(config.firebase);
  auth = getAuth(app);
  await setPersistence(auth, browserLocalPersistence);
  try {
    db = initializeFirestore(app, { localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }) });
  } catch (e) {
    console.warn('Cache persistente indisponível, usando memória', e);
    db = initializeFirestore(app, {});
  }
}

// ---------- conversões ----------
const tsToMs = (v) => (v instanceof Timestamp ? v.toMillis() : (typeof v === 'number' ? v : null));
function fromDoc(snap) {
  const d = snap.data({ serverTimestamps: 'estimate' });
  const o = { id: snap.id, ...d };
  for (const k of Object.keys(o)) if (o[k] instanceof Timestamp) o[k] = o[k].toMillis();
  o._pendente = snap.metadata.hasPendingWrites;
  return o;
}
function toWrite(obj) {
  const r = {};
  for (const [k, v] of Object.entries(obj)) {
    if (k === 'id' || k.startsWith('_')) continue;
    r[k] = v === NOW ? serverTimestamp() : v === undefined ? null : v;
  }
  return r;
}

// ---------- autenticação ----------
export function onAuth(cb) {
  return onAuthStateChanged(auth, (u) => cb(u ? { uid: u.uid, email: (u.email || '').toLowerCase() } : null));
}
export async function login(email, senha) { await signInWithEmailAndPassword(auth, email.trim(), senha); }
export async function logout() { await signOut(auth); }
export async function resetSenha(email) { await sendPasswordResetEmail(auth, email.trim()); }
export async function trocarSenha(atual, nova) {
  const u = auth.currentUser;
  await reauthenticateWithCredential(u, EmailAuthProvider.credential(u.email, atual));
  await updatePassword(u, nova);
}

// ---------- usuários ----------
export function watchUsuarios(cb, onErr) {
  return onSnapshot(collection(db, 'usuarios'), (s) => cb(s.docs.map(fromDoc)), onErr);
}
export async function salvarPerfil(uid, dados) {
  await setDoc(doc(db, 'usuarios', uid), toWrite({ ...dados, atualizadoEm: NOW }), { merge: true });
}

// ---------- clientes ----------
export function watchClientes(cb, onErr) {
  return onSnapshot(collection(db, 'clientes'), (s) => cb(s.docs.map(fromDoc)), onErr);
}
export async function salvarCliente(id, dados, user) {
  if (id) {
    const ref = doc(db, 'clientes', id);
    await setDoc(ref, toWrite({ ...dados, atualizadoPor: user, atualizadoEm: NOW }), { merge: true });
    return id;
  }
  const ref = doc(collection(db, 'clientes'));
  await setDoc(ref, toWrite({ ...dados, criadoPor: user, criadoEm: NOW, atualizadoPor: user, atualizadoEm: NOW }));
  return ref.id;
}
export async function excluirCliente(id) {
  const b = writeBatch(db); b.delete(doc(db, 'clientes', id)); await b.commit();
}

// ---------- ordens de serviço ----------
function queryOrdens(f) {
  const c = collection(db, 'ordens');
  if (f.pendentes) return query(c, where('status', 'in', ['agendado', 'andamento']));
  if (f.clienteId) return query(c, where('clienteId', '==', f.clienteId));
  if (f.concluidosDesde) return query(c, where('concluidoEm', '>=', Timestamp.fromMillis(f.concluidosDesde)));
  const cond = [];
  if (f.from) cond.push(where('data', '>=', f.from));
  if (f.to) cond.push(where('data', '<=', f.to));
  return query(c, ...cond);
}
export function watchOrdens(filtro, cb, onErr) {
  return onSnapshot(queryOrdens(filtro), { includeMetadataChanges: true }, (s) => cb(s.docs.map(fromDoc)), onErr);
}
export async function getOrdens(filtro) {
  const s = await getDocs(queryOrdens(filtro || {}));
  return s.docs.map(fromDoc);
}
export async function getOrdem(id) {
  const s = await getDoc(doc(db, 'ordens', id));
  return s.exists() ? fromDoc(s) : null;
}

function hist(osId, numero, tipo, user, extra = {}) {
  return toWrite({ osId, osNumero: numero, tipo, usuario: user, usuarioUid: user.uid, em: NOW, alteracoes: [], nota: '', ...extra });
}

export async function criarOrdem(campos, user, nota = '') {
  if (!navigator.onLine) throw new Error('Sem internet: é preciso estar conectado para gerar o número da OS.');
  return runTransaction(db, async (tx) => {
    const cRef = doc(db, 'contadores', 'os');
    const c = await tx.get(cRef);
    const numero = c.exists() ? c.data().ultimo + 1 : Math.max(1, Number(cfg.numeroInicialOS) || 1);
    const id = fmtNumOS(numero);
    const oRef = doc(db, 'ordens', id);
    const existente = await tx.get(oRef);
    if (existente.exists()) throw new Error(`O número ${id} já existe. Tente novamente.`);
    const concl = campos.status === 'concluido';
    tx.set(cRef, { ultimo: numero });
    tx.set(oRef, toWrite({
      ...campos, numero,
      criadoPor: user, criadoEm: NOW, atualizadoPor: user, atualizadoEm: NOW,
      statusPor: user, statusEm: NOW, concluidoPor: concl ? user : null, concluidoEm: concl ? NOW : null,
    }));
    tx.set(doc(collection(db, 'historico')), hist(id, numero, 'criacao', user, {
      nota, statusNovo: campos.status,
    }));
    return { id, numero };
  });
}

export async function atualizarOrdem(id, numero, patch, h, user) {
  const b = writeBatch(db);
  b.update(doc(db, 'ordens', id), toWrite({ ...patch, atualizadoPor: user, atualizadoEm: NOW }));
  b.set(doc(collection(db, 'historico')), hist(id, numero, h.tipo, user, { alteracoes: h.alteracoes || [], nota: h.nota || '' }));
  await b.commit();
}

export async function excluirOrdem(os, user) {
  const b = writeBatch(db);
  const snapshot = { ...os }; delete snapshot._pendente; delete snapshot.id;
  // o registro de exclusão tem id fixo, exigido pelas regras de segurança
  b.set(doc(db, 'historico', `exclusao_${os.id}`), hist(os.id, os.numero, 'exclusao', user, { copia: JSON.stringify(snapshot) }));
  b.delete(doc(db, 'ordens', os.id));
  await b.commit();
}

// ---------- histórico (auditoria) ----------
export function watchHistorico(filtro, cb, onErr) {
  const c = collection(db, 'historico');
  const q = filtro.osId ? query(c, where('osId', '==', filtro.osId)) : query(c, orderBy('em', 'desc'), limit(filtro.limite || 300));
  return onSnapshot(q, (s) => cb(s.docs.map(fromDoc)), onErr);
}

// ---------- backup ----------
export async function exportarTudo() {
  const out = {};
  for (const col of ['ordens', 'clientes', 'historico', 'usuarios', 'contadores']) {
    const s = await getDocs(collection(db, col));
    out[col] = s.docs.map(fromDoc).map((o) => { delete o._pendente; return o; });
  }
  return out;
}
