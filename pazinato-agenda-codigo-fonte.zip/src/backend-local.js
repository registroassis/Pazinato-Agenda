// MODO TESTE LOCAL — usado somente enquanto o Firebase não foi configurado.
// Os dados ficam apenas neste navegador (localStorage) e são sincronizados entre abas,
// para permitir testar o fluxo de dois usuários. Não é usado em produção.
import { NOW, fmtNumOS } from './util.js';

export const nome = 'local';
const KEY = 'osapp_teste_db_v1';
const USERS = {
  'pazinato@teste.com': { uid: 'teste-pazinato', senha: 'teste123' },
};
let cfg;
const watchers = new Set();
let bc;

function load() {
  try { return JSON.parse(localStorage.getItem(KEY)) || null; } catch { return null; }
}
function db() {
  return load() || { usuarios: {}, clientes: {}, ordens: {}, historico: {}, contadores: {} };
}
function save(d) {
  localStorage.setItem(KEY, JSON.stringify(d));
  notify();
  try { bc && bc.postMessage('change'); } catch {}
}
function notify() { for (const w of watchers) w(); }
const delay = () => new Promise((r) => setTimeout(r, 30));
let seq = 0;
const novoId = () => Date.now().toString(36) + (seq++).toString(36) + Math.random().toString(36).slice(2, 6);
function resolve(obj) {
  const r = {}; const t = Date.now();
  for (const [k, v] of Object.entries(obj)) { if (k === 'id' || k.startsWith('_')) continue; r[k] = v === NOW ? t : v === undefined ? null : v; }
  return r;
}
function watch(fn) { watchers.add(fn); fn(); return () => watchers.delete(fn); }

export async function init(config) {
  cfg = config;
  window.addEventListener('storage', (e) => { if (e.key === KEY) notify(); });
  try { bc = new BroadcastChannel('osapp_teste'); bc.onmessage = () => notify(); } catch {}
}

// ---------- autenticação (sessão por aba, para testar 2 usuários) ----------
let authCbs = [];
function sessao() { try { return JSON.parse(sessionStorage.getItem('osapp_teste_user')); } catch { return null; } }
export function onAuth(cb) { authCbs.push(cb); setTimeout(() => cb(sessao()), 0); return () => {}; }
export async function login(email, senha) {
  await delay();
  const e = email.trim().toLowerCase(); const u = USERS[e];
  if (!u || u.senha !== senha) { const err = new Error('auth'); err.code = 'auth/invalid-credential'; throw err; }
  const user = { uid: u.uid, email: e };
  sessionStorage.setItem('osapp_teste_user', JSON.stringify(user));
  authCbs.forEach((cb) => cb(user));
}
export async function logout() { sessionStorage.removeItem('osapp_teste_user'); authCbs.forEach((cb) => cb(null)); }
export async function resetSenha() { await delay(); }
export async function trocarSenha() { await delay(); throw new Error('No modo teste a senha é fixa (teste123).'); }

// ---------- usuários ----------
export function watchUsuarios(cb) { return watch(() => cb(Object.entries(db().usuarios).map(([id, v]) => ({ id, ...v })))); }
export async function salvarPerfil(uid, dados) {
  await delay(); const d = db(); d.usuarios[uid] = { ...(d.usuarios[uid] || {}), ...resolve({ ...dados, atualizadoEm: NOW }) }; save(d);
}

// ---------- clientes ----------
export function watchClientes(cb) { return watch(() => cb(Object.entries(db().clientes).map(([id, v]) => ({ id, ...v })))); }
export async function salvarCliente(id, dados, user) {
  await delay(); const d = db();
  if (id) { d.clientes[id] = { ...d.clientes[id], ...resolve({ ...dados, atualizadoPor: user, atualizadoEm: NOW }) }; save(d); return id; }
  const nid = novoId();
  d.clientes[nid] = resolve({ ...dados, criadoPor: user, criadoEm: NOW, atualizadoPor: user, atualizadoEm: NOW });
  save(d); return nid;
}
export async function excluirCliente(id) { await delay(); const d = db(); delete d.clientes[id]; save(d); }

// ---------- ordens ----------
function filtra(f, list) {
  if (f.pendentes) return list.filter((o) => o.status === 'agendado' || o.status === 'andamento');
  if (f.clienteId) return list.filter((o) => o.clienteId === f.clienteId);
  if (f.concluidosDesde) return list.filter((o) => o.concluidoEm && o.concluidoEm >= f.concluidosDesde);
  return list.filter((o) => (!f.from || o.data >= f.from) && (!f.to || o.data <= f.to));
}
const todas = () => Object.entries(db().ordens).map(([id, v]) => ({ id, ...v }));
export function watchOrdens(f, cb) { return watch(() => cb(filtra(f, todas()))); }
export async function getOrdens(f) { await delay(); return filtra(f || {}, todas()); }
export async function getOrdem(id) { const o = db().ordens[id]; return o ? { id, ...o } : null; }

function hist(osId, numero, tipo, user, extra = {}) {
  return resolve({ osId, osNumero: numero, tipo, usuario: user, usuarioUid: user.uid, em: NOW, alteracoes: [], nota: '', ...extra });
}
export async function criarOrdem(campos, user, nota = '') {
  await delay(); const d = db();
  const numero = d.contadores.os ? d.contadores.os.ultimo + 1 : Math.max(1, Number(cfg.numeroInicialOS) || 1);
  const id = fmtNumOS(numero);
  if (d.ordens[id]) throw new Error('Número já usado');
  const concl = campos.status === 'concluido';
  d.contadores.os = { ultimo: numero };
  d.ordens[id] = resolve({ ...campos, numero, criadoPor: user, criadoEm: NOW, atualizadoPor: user, atualizadoEm: NOW,
    statusPor: user, statusEm: NOW, concluidoPor: concl ? user : null, concluidoEm: concl ? NOW : null });
  d.historico[novoId()] = hist(id, numero, 'criacao', user, { nota, statusNovo: campos.status });
  save(d); return { id, numero };
}
export async function atualizarOrdem(id, numero, patch, h, user) {
  await delay(); const d = db();
  if (!d.ordens[id]) throw new Error('OS não encontrada (pode ter sido excluída).');
  d.ordens[id] = { ...d.ordens[id], ...resolve({ ...patch, atualizadoPor: user, atualizadoEm: NOW }) };
  d.historico[novoId()] = hist(id, numero, h.tipo, user, { alteracoes: h.alteracoes || [], nota: h.nota || '' });
  save(d);
}
export async function excluirOrdem(os, user) {
  await delay(); const d = db();
  const copia = { ...os }; delete copia.id; delete copia._pendente;
  d.historico[`exclusao_${os.id}`] = hist(os.id, os.numero, 'exclusao', user, { copia: JSON.stringify(copia) });
  delete d.ordens[os.id]; save(d);
}

// ---------- histórico ----------
export function watchHistorico(f, cb) {
  return watch(() => {
    let l = Object.entries(db().historico).map(([id, v]) => ({ id, ...v }));
    if (f.osId) l = l.filter((h) => h.osId === f.osId);
    else l = l.sort((a, b) => b.em - a.em).slice(0, f.limite || 300);
    cb(l);
  });
}
export async function exportarTudo() {
  const d = db(); const arr = (o) => Object.entries(o).map(([id, v]) => ({ id, ...v }));
  return { ordens: arr(d.ordens), clientes: arr(d.clientes), historico: arr(d.historico), usuarios: arr(d.usuarios), contadores: arr(d.contadores) };
}
