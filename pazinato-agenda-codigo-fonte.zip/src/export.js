// Exportações: PDF (jsPDF + autoTable), Excel (SheetJS) e impressão. Carregado sob demanda.
import { jsPDF } from 'jspdf';
import { autoTable } from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { esc } from './util.js';

const CFG = () => window.APP_CONFIG || {};

function hexToRgb(h) { const m = /^#?([0-9a-f]{6})$/i.exec(h || ''); if (!m) return [15, 61, 94]; const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }

async function carregarLogo() {
  try {
    const r = await fetch(CFG().logoHorizontal || CFG().logo || 'assets/logo.png', { cache: 'no-cache' });
    if (!r.ok) return null;
    const blob = await r.blob();
    if (!/image\/(png|jpe?g)/.test(blob.type)) return null;
    const url = await new Promise((res) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.readAsDataURL(blob); });
    const dim = await new Promise((res) => { const i = new Image(); i.onload = () => res([i.naturalWidth, i.naturalHeight]); i.onerror = () => res([1, 1]); i.src = url; });
    return { url, w: dim[0], h: dim[1], tipo: blob.type.includes('png') ? 'PNG' : 'JPEG' };
  } catch { return null; }
}

function nomeArquivo(rel, ext) {
  const base = `${rel.titulo} - ${rel.periodo}`.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w\- ]+/g, '').replace(/\s+/g, '_');
  return `${base}.${ext}`;
}

export async function salvarArquivo(blob, nome) {
  const file = new File([blob], nome, { type: blob.type });
  const mobile = /iphone|ipad|android/i.test(navigator.userAgent);
  if (mobile && navigator.canShare && navigator.canShare({ files: [file] })) {
    try { await navigator.share({ files: [file], title: nome }); return; } catch (e) { if (e.name === 'AbortError') return; }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = nome; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 2000);
}

export async function gerarPDF(rel) {
  const cfg = CFG(); const cor = hexToRgb(cfg.cores && cfg.cores.primaria);
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth(); const H = doc.internal.pageSize.getHeight();
  const logo = await carregarLogo();
  let x = 14;
  if (logo) { const h = logo.w > logo.h * 1.5 ? 14 : 18; const w = Math.min(60, (logo.w / logo.h) * h); doc.addImage(logo.url, logo.tipo, 14, 10, w, h); x = 14 + w + 5; }
  doc.setTextColor(...cor); doc.setFont('helvetica', 'bold'); doc.setFontSize(15);
  doc.text(cfg.nomeEmpresa || 'Empresa', x, 16);
  doc.setFontSize(12); doc.setTextColor(40); doc.text(rel.titulo, x, 23);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(80);
  doc.text(`Período: ${rel.periodo}`, W - 14, 13, { align: 'right' });
  doc.text(`Filtros: ${rel.filtros}`, W - 14, 18, { align: 'right', maxWidth: 140 });
  doc.text(`Emitido em ${rel.emitidoEm} por ${rel.emitidoPor}`, W - 14, 23, { align: 'right' });
  doc.setDrawColor(...cor); doc.setLineWidth(0.6); doc.line(14, 29, W - 14, 29);

  autoTable(doc, {
    startY: 33, theme: 'grid', head: [rel.resumo.map((r) => r[0])], body: [rel.resumo.map((r) => String(r[1]))],
    headStyles: { fillColor: [240, 243, 247], textColor: 60, fontStyle: 'normal', fontSize: 8 }, bodyStyles: { fontStyle: 'bold', fontSize: 11, halign: 'center' },
    margin: { left: 14, right: 14 },
  });
  for (const s of rel.secoes) {
    let y = doc.lastAutoTable.finalY + 8;
    if (y > H - 30) { doc.addPage(); y = 20; }
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5); doc.setTextColor(...cor); doc.text(s.titulo, 14, y);
    autoTable(doc, {
      startY: y + 3, head: [s.colunas], body: s.linhas.length ? s.linhas.map((l) => l.map((c) => String(c ?? ''))) : [[{ content: 'Nenhum registro.', colSpan: s.colunas.length }]],
      styles: { fontSize: 7.5, cellPadding: 1.6, overflow: 'linebreak', valign: 'top' },
      headStyles: { fillColor: cor, textColor: 255, fontSize: 7.5 }, alternateRowStyles: { fillColor: [247, 249, 251] },
      margin: { left: 14, right: 14, top: 16 },
      didParseCell: (d) => {
        if (d.section !== 'body' || d.column.dataKey === undefined) return;
        const v = String(d.cell.raw || '');
        if (s.colunas[d.column.index] === 'Status') {
          if (v === 'Concluído') d.cell.styles.textColor = [22, 128, 61];
          if (v === 'Em andamento') d.cell.styles.textColor = [29, 78, 216];
          if (v === 'Agendado') d.cell.styles.textColor = [194, 65, 12];
          d.cell.styles.fontStyle = 'bold';
        }
      },
    });
  }
  const n = doc.getNumberOfPages();
  for (let i = 1; i <= n; i++) {
    doc.setPage(i); doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(130);
    doc.text(`${cfg.nomeEmpresa || ''} · ${rel.titulo} · ${rel.periodo}`, 14, H - 7);
    doc.text(`Página ${i} de ${n}`, W - 14, H - 7, { align: 'right' });
  }
  await salvarArquivo(doc.output('blob'), nomeArquivo(rel, 'pdf'));
}

export async function gerarXLSX(rel) {
  const cfg = CFG(); const wb = XLSX.utils.book_new();
  const linhas = [[cfg.nomeEmpresa || ''], [rel.titulo], [`Período: ${rel.periodo}`], [`Filtros: ${rel.filtros}`], [`Emitido em ${rel.emitidoEm} por ${rel.emitidoPor}`], []];
  linhas.push(['Resumo']); rel.resumo.forEach((r) => linhas.push([r[0], r[1]])); linhas.push([]);
  const merges = [];
  for (const s of rel.secoes) { linhas.push([s.titulo]); linhas.push(s.colunas); s.linhas.forEach((l) => linhas.push(l)); linhas.push([]); }
  const ws = XLSX.utils.aoa_to_sheet(linhas);
  const maxCols = Math.max(...rel.secoes.map((s) => s.colunas.length), 2);
  ws['!cols'] = Array.from({ length: maxCols }, (_, i) => ({ wch: [8, 11, 8, 28, 16, 22, 10, 40, 14, 16, 26][i] || 16 }));
  ws['!merges'] = merges;
  XLSX.utils.book_append_sheet(wb, ws, 'Relatório');
  // uma aba por seção com tabela "limpa" (bom para filtrar/ordenar no Excel)
  rel.secoes.forEach((s, i) => {
    if (!s.linhas.length) return;
    const w = XLSX.utils.aoa_to_sheet([s.colunas, ...s.linhas]);
    w['!cols'] = s.colunas.map((c) => ({ wch: Math.max(10, Math.min(45, c.length + 6, ...s.linhas.slice(0, 200).map((l) => String(l[s.colunas.indexOf(c)] ?? '').length + 2))) }));
    w['!autofilter'] = { ref: XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: s.linhas.length, c: s.colunas.length - 1 } }) };
    XLSX.utils.book_append_sheet(wb, w, `Dados ${i + 1}`.slice(0, 31));
  });
  const out = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  await salvarArquivo(new Blob([out], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), nomeArquivo(rel, 'xlsx'));
}

export function imprimir(rel) {
  const cfg = CFG(); const area = document.getElementById('print-area');
  area.innerHTML = `
    <div class="pr-cab"><img src="${esc(cfg.logoHorizontal || cfg.logo || 'assets/logo.png')}" alt="" onerror="this.remove()"><div><h1>${esc(cfg.nomeEmpresa || '')}</h1><h2>${esc(rel.titulo)}</h2></div>
      <div class="pr-meta">Período: ${esc(rel.periodo)}<br>Filtros: ${esc(rel.filtros)}<br>Emitido em ${esc(rel.emitidoEm)} por ${esc(rel.emitidoPor)}</div></div>
    <table class="pr-resumo"><tr>${rel.resumo.map((r) => `<td><small>${esc(r[0])}</small><b>${esc(r[1])}</b></td>`).join('')}</tr></table>
    ${rel.secoes.map((s) => `<h3>${esc(s.titulo)}</h3><table class="pr-tab"><thead><tr>${s.colunas.map((c) => `<th>${esc(c)}</th>`).join('')}</tr></thead>
      <tbody>${s.linhas.map((l) => `<tr>${l.map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${s.colunas.length}">Nenhum registro.</td></tr>`}</tbody></table>`).join('')}`;
  setTimeout(() => window.print(), 300);
}

// Backup completo (JSON + Excel)
export async function backupCompleto(dados) {
  const cfg = CFG(); const d = new Date();
  const stamp = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}_${String(d.getHours()).padStart(2, '0')}${String(d.getMinutes()).padStart(2, '0')}`;
  const json = new Blob([JSON.stringify({ app: cfg.nomeApp, geradoEm: d.toISOString(), ...dados }, null, 2)], { type: 'application/json' });
  const wb = XLSX.utils.book_new();
  const plano = (o) => Object.fromEntries(Object.entries(o).map(([k, v]) => [k, v && typeof v === 'object' ? (v.nome || JSON.stringify(v)) : (typeof v === 'number' && /Em$/.test(k) && v > 1e11 ? new Date(v).toLocaleString('pt-BR') : v)]));
  for (const col of ['ordens', 'clientes', 'historico', 'usuarios']) {
    const l = (dados[col] || []).map(plano);
    XLSX.utils.book_append_sheet(wb, l.length ? XLSX.utils.json_to_sheet(l) : XLSX.utils.aoa_to_sheet([['(vazio)']]), col);
  }
  const xlsx = new Blob([XLSX.write(wb, { bookType: 'xlsx', type: 'array' })], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  return { json, xlsx, nomeJson: `backup_${stamp}.json`, nomeXlsx: `backup_${stamp}.xlsx` };
}
