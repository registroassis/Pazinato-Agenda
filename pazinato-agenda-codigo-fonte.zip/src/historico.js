// Formatação das linhas do histórico de auditoria.
import { esc, fmtMs, statusLabel, CAMPOS_OS, fmtValorCampo, fmtNumOS } from './util.js';
import { nomeUsuario } from './store.js';

export function textoHistorico(h) {
  const quem = nomeUsuario(h.usuario);
  const quando = fmtMs(h.em);
  switch (h.tipo) {
    case 'criacao':
      return { titulo: `Criada por ${quem}`, quando, detalhes: [`Status inicial: ${statusLabel(h.statusNovo || 'agendado')}`, h.nota].filter(Boolean) };
    case 'status': {
      const a = (h.alteracoes || [])[0] || {};
      return { titulo: `Status alterado de ${statusLabel(a.de)} para ${statusLabel(a.para)} por ${quem}`, quando, detalhes: [], status: a.para };
    }
    case 'edicao':
      return {
        titulo: `Editada por ${quem}`, quando,
        detalhes: (h.alteracoes || []).map((x) => `${CAMPOS_OS[x.campo] || x.campo}: ${fmtValorCampo(x.campo, x.de)} → ${fmtValorCampo(x.campo, x.para)}`),
        status: (h.alteracoes || []).find((x) => x.campo === 'status')?.para,
      };
    case 'exclusao':
      return { titulo: `OS excluída por ${quem}`, quando, detalhes: ['Uma cópia dos dados da OS foi guardada no histórico.'] };
    default:
      return { titulo: `${h.tipo} por ${quem}`, quando, detalhes: [] };
  }
}

export function timelineHtml(lista, { mostrarOS = false } = {}) {
  if (!lista.length) return '<div class="vazio peq">Nenhum registro.</div>';
  return `<ol class="timeline">${lista.map((h) => {
    const t = textoHistorico(h);
    return `<li class="tl-item tl-${esc(h.tipo)} ${t.status ? 'st-' + esc(t.status) : ''}">
      <div class="tl-dot"></div>
      <div class="tl-corpo">
        ${mostrarOS ? (h.tipo === 'exclusao' ? `<span class="tl-os">OS ${fmtNumOS(h.osNumero)}</span>` : `<a class="tl-os" href="#/os/${esc(h.osId)}">OS ${fmtNumOS(h.osNumero)}</a>`) : ''}
        <div class="tl-tit">${esc(t.titulo)}</div>
        <div class="tl-qdo">${esc(t.quando)}</div>
        ${t.detalhes.length ? `<ul class="tl-det">${t.detalhes.map((d) => `<li>${esc(d)}</li>`).join('')}</ul>` : ''}
      </div></li>`;
  }).join('')}</ol>`;
}
