// Inicialização, layout e roteamento.
import { esc } from './util.js';
import { state, setBackend, onChange, emit, iniciarAssinaturasBase, encerrarAssinaturas, pessoaSalva, escolherPessoa, pessoasConfig, esquecerPessoa } from './store.js';
import { ic, toast } from './ui.js';
import { parseHash, go } from './router.js';
import { telaInicio, telaAgenda } from './views-agenda.js';
import { telaListaOS, telaFormOS, telaDetalheOS, acaoStatusCartao } from './views-os.js';
import { telaClientes, telaCliente } from './views-clientes.js';
import { telaRelatorios } from './views-relatorios.js';
import { telaConfig, telaPerfil, telaHistorico, telaLogin, telaQuemUsa } from './views-config.js';
import { iniciarNotificacoes } from './notify.js';

const CFG = window.APP_CONFIG || {};
const app = document.getElementById('app');

function aplicarTema() {
  const c = CFG.cores || {}; const r = document.documentElement.style;
  if (c.primaria) r.setProperty('--pri', c.primaria);
  if (c.primariaEscura) r.setProperty('--pri-esc', c.primariaEscura);
  if (c.destaque) r.setProperty('--dest', c.destaque);
  document.title = CFG.nomeApp || document.title;
  const m = document.querySelector('meta[name="theme-color"]'); if (m && c.primaria) m.content = c.primaria;
}

function firebaseConfigurado() {
  const f = CFG.firebase || {};
  return f.apiKey && !/COLE|SUA|xxx/i.test(f.apiKey) && f.projectId && !/COLE|SEU/i.test(f.projectId);
}

function telaSetup() {
  app.innerHTML = `<div class="login"><div class="login-marca"><img src="${esc(CFG.logo || 'assets/logo.png')}" class="login-logo" alt="" onerror="this.style.display='none'"><h1>${esc(CFG.nomeApp || 'Agenda de OS')}</h1></div>
    <div class="painel"><h2>Configuração pendente</h2>
    <p>O banco de dados (Firebase) ainda não foi configurado. Preencha o arquivo <b>config.js</b> com os dados do projeto Firebase, conforme o guia de instalação.</p>
    <p class="muted">Para conhecer o app antes da configuração, use o modo teste (os dados ficam apenas neste navegador e não são compartilhados):</p>
    <a class="btn btn-sec bloco" href="?teste=local">Abrir em modo teste local</a></div></div>`;
}

const ROTAS = [
  [/^inicio$/, () => [telaInicio]],
  [/^agenda$/, () => [telaAgenda]],
  [/^os$/, () => [telaListaOS]],
  [/^os\/nova$/, () => [telaFormOS, { modo: 'nova' }]],
  [/^os\/([^/]+)\/editar$/, (m) => [telaFormOS, { modo: 'editar', id: m[1] }]],
  [/^os\/([^/]+)\/duplicar$/, (m) => [telaFormOS, { modo: 'duplicar', id: m[1] }]],
  [/^os\/([^/]+)$/, (m) => [telaDetalheOS, { id: m[1] }]],
  [/^clientes$/, () => [telaClientes]],
  [/^clientes\/([^/]+)$/, (m) => [telaCliente, { id: m[1] }]],
  [/^relatorios$/, () => [telaRelatorios]],
  [/^config$/, () => [telaConfig]],
  [/^perfil$/, () => [telaPerfil]],
  [/^historico$/, () => [telaHistorico]],
];
const NAV = [['inicio', 'Início', 'home'], ['agenda', 'Agenda', 'agenda'], ['os', 'Ordens', 'os'], ['clientes', 'Clientes', 'clientes'], ['relatorios', 'Relatórios', 'rel']];

let tela = null;
function montarLayout() {
  app.innerHTML = `
    <header class="topo">
      <button class="icon-btn topo-voltar" data-voltar aria-label="Voltar" hidden>${ic('left')}</button>
      <a class="topo-marca" href="#/inicio" data-marca><img src="${esc(CFG.logo || 'assets/logo.png')}" alt="" onerror="this.style.display='none'"></a>
      <h1 class="topo-titulo" data-titulo></h1>
      <button class="chip-pessoa" data-pessoa aria-label="Trocar usuário">${ic('user')}<span></span></button>
      <a class="icon-btn" href="#/os" aria-label="Pesquisar">${ic('search')}</a>
      <a class="icon-btn" href="#/config" aria-label="Configurações">${ic('gear')}</a>
    </header>
    <div class="faixas" data-faixas></div>
    <main id="main" class="main"></main>
    <button class="fab" data-fab aria-label="Nova ordem de serviço">${ic('plus')}<span>Nova OS</span></button>
    <nav class="nav-inf">${NAV.map(([k, l, i]) => `<a href="#/${k}" data-nav="${k}">${ic(i)}<span>${l}</span></a>`).join('')}</nav>`;
  app.querySelector('[data-pessoa]').onclick = () => trocarPessoa();
  app.querySelector('[data-voltar]').onclick = () => (history.length > 1 ? history.back() : go('#/inicio'));
  app.querySelector('[data-fab]').onclick = () => {
    const { parts, q } = parseHash();
    const d = parts[0] === 'agenda' && q.get('v') === 'dia' && q.get('d') ? '?d=' + q.get('d') : '';
    go('#/os/nova' + d);
  };
  const main = app.querySelector('#main');
  main.addEventListener('click', (e) => {
    const a = e.target.closest('[data-abrir]'); if (a) { e.preventDefault(); go('#/os/' + a.dataset.abrir); return; }
    const s = e.target.closest('[data-status]'); if (s) { e.preventDefault(); acaoStatusCartao(s.dataset.status); }
  });
}

function faixas() {
  const el = app.querySelector('[data-faixas]'); if (!el) return;
  const f = [];
  if (window.__backend && window.__backend.nome === 'local') f.push('<div class="faixa teste">MODO TESTE LOCAL — dados apenas neste navegador</div>');
  if (!state.online) f.push('<div class="faixa off">Sem internet — as alterações serão enviadas quando a conexão voltar</div>');
  if (state.erro) f.push(`<div class="faixa erro">${esc(state.erro)}</div>`);
  el.innerHTML = f.join('');
}

function atualizarChipPessoa() {
  const b = app.querySelector('[data-pessoa] span'); if (b && state.me) b.textContent = state.me.pessoa;
}
async function trocarPessoa() {
  if (tela && tela.unmount) tela.unmount();
  tela = null;
  document.body.classList.add('deslogado');
  const p = await telaQuemUsa(app, pessoasConfig(), state.me && state.me.pessoa);
  document.body.classList.remove('deslogado');
  if (!state.user) return;
  escolherPessoa(p);
  montarLayout(); faixas(); atualizarChipPessoa();
  await rotear();
}
window.__trocarPessoa = trocarPessoa;
window.__esquecerPessoa = esquecerPessoa;

async function rotear() {
  if (!state.user) return;
  const { parts, q } = parseHash();
  const path = parts.join('/');
  let alvo = null;
  for (const [re, fn] of ROTAS) { const m = path.match(re); if (m) { alvo = fn(m); break; } }
  if (!alvo) { go('#/inicio', true); return; }
  if (tela && tela.unmount) tela.unmount();
  const [view, params = {}] = alvo;
  tela = view;
  const main = app.querySelector('#main');
  main.innerHTML = '';
  main.className = 'main tela-' + parts[0];
  document.body.classList.toggle('modo-home', !!view.home);
  app.querySelector('[data-titulo]').textContent = view.titulo || '';
  app.querySelector('[data-voltar]').hidden = !view.voltar;
  app.querySelector('[data-marca]').hidden = !!view.voltar;
  app.querySelector('[data-fab]').hidden = !view.fab;
  app.querySelectorAll('[data-nav]').forEach((a) => a.classList.toggle('on', a.dataset.nav === parts[0] || (parts[0] === 'perfil' && false)));
  window.scrollTo(0, 0);
  try { await view.mount(main, params, q); } catch (e) { console.error(e); main.innerHTML = `<div class="vazio">Erro ao abrir a tela: ${esc(e.message)}</div>`; }
}

async function boot() {
  aplicarTema();
  const teste = new URLSearchParams(location.search).get('teste') === 'local';
  let backend;
  if (firebaseConfigurado()) backend = await import('./backend-firebase.js');
  else if (teste) backend = await import('./backend-local.js');
  else { telaSetup(); return; }
  window.__backend = backend;
  setBackend(backend);
  try { await backend.init(CFG); } catch (e) { app.innerHTML = `<div class="login"><div class="painel"><h2>Erro ao iniciar</h2><p>${esc(e.message)}</p><p class="muted">Confira os dados do Firebase no arquivo config.js.</p></div></div>`; return; }

  window.addEventListener('online', () => { state.online = true; emit(); });
  window.addEventListener('offline', () => { state.online = false; emit(); });
  window.addEventListener('hashchange', rotear);
  onChange(() => { faixas(); if (tela && !tela.estatico && tela.update && state.user) tela.update(); });

  let primeira = true;
  backend.onAuth(async (u) => {
    encerrarAssinaturas(); state.erro = null;
    if (!u) {
      state.user = null; state.me = null; tela = null;
      document.body.classList.add('deslogado');
      telaLogin(app); return;
    }
    document.body.classList.remove('deslogado');
    state.user = u;
    let pessoa = pessoaSalva();
    if (!pessoa) { document.body.classList.add('deslogado'); pessoa = await telaQuemUsa(app, pessoasConfig()); document.body.classList.remove('deslogado'); }
    if (!state.user) return;
    escolherPessoa(pessoa);
    montarLayout(); faixas(); atualizarChipPessoa();
    iniciarAssinaturasBase();
    await rotear();
    if (primeira) { primeira = false; iniciarNotificacoes(); }
  });
}

if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch((e) => console.warn('SW', e)));
  navigator.serviceWorker && navigator.serviceWorker.addEventListener('message', (e) => { if (e.data && e.data.url) location.hash = e.data.url.replace(/^.*#/, '#'); });
}
boot();
