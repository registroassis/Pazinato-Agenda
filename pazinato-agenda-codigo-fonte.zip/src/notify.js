// Notificações e lembretes locais (configuráveis por aparelho).
// Funcionam enquanto o app está aberto ou em segundo plano recente. Avisos com o app
// totalmente fechado exigiriam um servidor de push (Cloud Functions — plano pago do Firebase).
import { hojeISO, fmtNumOS } from './util.js';
import { resumoHoje, state } from './store.js';

const KEY = 'osapp_notif_v1';
export const PADRAO = { ativo: false, resumoDiario: true, horaResumo: '07:30', lembreteMin: 30, andamento: true, atrasados: true };
export function lerPrefs() { try { return { ...PADRAO, ...(JSON.parse(localStorage.getItem(KEY)) || {}) }; } catch { return { ...PADRAO }; } }
export function salvarPrefs(p) { localStorage.setItem(KEY, JSON.stringify(p)); }
export const suportado = () => 'Notification' in window;
export const permissao = () => (suportado() ? Notification.permission : 'unsupported');
export async function pedirPermissao() { if (!suportado()) return 'unsupported'; return Notification.requestPermission(); }

function jaEnviado(chave) {
  const k = 'osapp_notif_enviadas'; let m = {};
  try { m = JSON.parse(localStorage.getItem(k)) || {}; } catch {}
  const h = hojeISO();
  for (const x of Object.keys(m)) if (m[x] < h) delete m[x];
  if (m[chave]) return true;
  m[chave] = h; localStorage.setItem(k, JSON.stringify(m)); return false;
}

export async function mostrar(titulo, corpo, url = '#/inicio', tag) {
  const cfg = window.APP_CONFIG || {};
  const opts = { body: corpo, icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', tag: tag || titulo, data: { url } };
  try {
    const reg = navigator.serviceWorker && (await navigator.serviceWorker.getRegistration());
    if (reg) { await reg.showNotification(titulo || cfg.nomeApp, opts); return true; }
  } catch {}
  try { new Notification(titulo, opts); return true; } catch { return false; }
}

function verificar() {
  const p = lerPrefs();
  if (!p.ativo || permissao() !== 'granted' || !state.me) return;
  const r = resumoHoje(); const agora = new Date();
  const hm = `${String(agora.getHours()).padStart(2, '0')}:${String(agora.getMinutes()).padStart(2, '0')}`;
  if (p.resumoDiario && hm >= p.horaResumo && !jaEnviado('resumo')) {
    const partes = [`${r.hoje.length} atendimento(s) hoje`];
    if (p.andamento && r.andamento.length) partes.push(`${r.andamento.length} em andamento`);
    if (p.atrasados && r.atrasados.length) partes.push(`${r.atrasados.length} atrasado(s)`);
    mostrar('Agenda de hoje', partes.join(' · '), '#/inicio', 'resumo');
  } else if (!p.resumoDiario) {
    if (p.atrasados && r.atrasados.length && hm >= p.horaResumo && !jaEnviado('atrasados')) mostrar('Serviços atrasados', `${r.atrasados.length} serviço(s) com data passada ainda não concluído(s).`, '#/os?p=atrasados', 'atrasados');
  }
  if (p.lembreteMin > 0) {
    for (const o of r.hoje) {
      if (!o.hora || o.status !== 'agendado') continue;
      const [H, M] = o.hora.split(':').map(Number); const ini = new Date(); ini.setHours(H, M, 0, 0);
      const falta = (ini - agora) / 60000;
      if (falta <= p.lembreteMin && falta > -5 && !jaEnviado('lembrete_' + o.id)) {
        mostrar(`Atendimento às ${o.hora}`, `OS ${fmtNumOS(o.numero)} · ${o.clienteNome}${o.veiculo ? ' · ' + o.veiculo : ''}`, `#/os/${o.id}`, 'lembrete_' + o.id);
      }
    }
  }
}
let timer;
export function iniciarNotificacoes() {
  clearInterval(timer);
  timer = setInterval(verificar, 60000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(verificar, 3000); });
  setTimeout(verificar, 8000);
}
