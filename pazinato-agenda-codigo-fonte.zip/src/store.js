// Estado do app + assinaturas em tempo real + ações (com registro de auditoria).
import { NOW, hojeISO, addDias, addMeses, ultimoDiaMes, normaliza, soDigitos, CAMPOS_OS, fmtNumOS } from './util.js';

export let backend = null;
export const state = {
  user: null, // {uid,email}
  me: null, // {uid,nome}
  perfil: null,
  usuarios: {},
  clientes: [],
  clientesCarregados: false,
  online: navigator.onLine,
  erro: null,
};
const listeners = new Set();
export function onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
let raf = 0;
export function emit() {
  if (raf) return;
  raf = requestAnimationFrame(() => { raf = 0; listeners.forEach((fn) => { try { fn(); } catch (e) { console.error(e); } }); });
}

export function setBackend(b) { backend = b; }

// ---------- assinaturas de OS por "janela" ----------
const janelas = new Map(); // key -> {unsub, docs: Map, ok:boolean, fixa, usado}
let usoSeq = 0;
function onErro(e) {
  console.error(e);
  state.erro = e && e.code === 'permission-denied'
    ? 'Acesso negado pelo banco de dados. Confirme se o seu e-mail está liberado nas regras de segurança.'
    : 'Falha de comunicação com o banco de dados: ' + (e && e.message ? e.message : e);
  emit();
}
export function garantirJanela(key, filtro, fixa = false) {
  let j = janelas.get(key);
  if (j) { j.usado = ++usoSeq; return j; }
  j = { docs: new Map(), ok: false, fixa, usado: ++usoSeq };
  janelas.set(key, j);
  j.unsub = backend.watchOrdens(filtro, (lista) => {
    j.docs = new Map(lista.map((o) => [o.id, o])); j.ok = true; emit();
  }, onErro);
  limparJanelas();
  return j;
}
function limparJanelas() {
  const moveis = [...janelas.entries()].filter(([, j]) => !j.fixa);
  if (moveis.length <= 10) return;
  moveis.sort((a, b) => a[1].usado - b[1].usado);
  for (const [k, j] of moveis.slice(0, moveis.length - 10)) { j.unsub && j.unsub(); janelas.delete(k); }
}
export function soltarJanela(key) { const j = janelas.get(key); if (j && !j.fixa) { j.unsub && j.unsub(); janelas.delete(key); } }
export function ordensDaJanela(key) { const j = janelas.get(key); return j ? [...j.docs.values()] : []; }
export function janelaPronta(key) { const j = janelas.get(key); return !!(j && j.ok); }

export function garantirMes(ym) { return garantirJanela('m:' + ym, { from: ym + '-01', to: ultimoDiaMes(ym) }); }
export function garantirPeriodo(from, to) {
  // assina mês a mês (reaproveita cache)
  let ym = from.slice(0, 7); const fim = to.slice(0, 7); let n = 0;
  while (ym <= fim && n < 14) { garantirMes(ym); ym = addMeses(ym + '-01', 1).slice(0, 7); n++; }
}
export function todasOrdens() {
  const m = new Map();
  for (const j of janelas.values()) for (const [id, o] of j.docs) {
    const atual = m.get(id);
    if (!atual || (o.atualizadoEm || 0) >= (atual.atualizadoEm || 0)) m.set(id, o);
  }
  // remove OS que alguma janela "autoritativa" (que cobre a data dela) já não contém (excluída/movida)
  return [...m.values()];
}
export function ordensNoPeriodo(from, to) { return todasOrdens().filter((o) => o.data >= from && o.data <= to); }
export function ordemPorId(id) { for (const j of janelas.values()) if (j.docs.has(id)) return j.docs.get(id); return null; }

export function iniciarAssinaturasBase() {
  const h = hojeISO();
  garantirJanela('p', { pendentes: true }, true);
  garantirJanela('m:' + h.slice(0, 7), { from: h.slice(0, 7) + '-01', to: ultimoDiaMes(h.slice(0, 7)) }, true);
  const prox = addMeses(h, 1).slice(0, 7);
  garantirJanela('m:' + prox, { from: prox + '-01', to: ultimoDiaMes(prox) }, true);
  const ini = new Date(); ini.setHours(0, 0, 0, 0);
  garantirJanela('ch', { concluidosDesde: ini.getTime() }, true);
  unsubs.push(backend.watchClientes((l) => { state.clientes = l.sort((a, b) => normaliza(a.nome).localeCompare(normaliza(b.nome))); state.clientesCarregados = true; emit(); }, onErro));
  carregarPessoas();
}
const unsubs = [];
export function encerrarAssinaturas() {
  unsubs.splice(0).forEach((u) => u && u());
  for (const j of janelas.values()) j.unsub && j.unsub();
  janelas.clear();
  state.clientes = []; state.usuarios = {}; state.clientesCarregados = false; state.usuariosCarregados = false; state.perfil = null;
}

export function nomeUsuario(u) {
  if (!u) return '—';
  return u.pessoa || u.nome || '—';
}
export const quem = (u) => (u ? u.pessoa || u.nome || '' : '');

// ---------- login único: quem está usando (Danilo / Juninho) ----------
const KEY_PESSOA = 'osapp_pessoa';
export function pessoasConfig() { return ((window.APP_CONFIG || {}).usuarios || []).filter(Boolean); }
function carregarPessoas() {
  state.usuarios = Object.fromEntries(pessoasConfig().map((n) => [n, { id: n, nome: n }]));
  state.usuariosCarregados = true;
}
export function pessoaSalva() {
  const p = localStorage.getItem(KEY_PESSOA);
  return pessoasConfig().includes(p) ? p : null;
}
export function escolherPessoa(nome) {
  localStorage.setItem(KEY_PESSOA, nome);
  state.me = { uid: state.user.uid, nome, pessoa: nome };
  emit();
}
export function esquecerPessoa() { localStorage.removeItem(KEY_PESSOA); }

// ---------- clientes ----------
export function buscarClienteDuplicado(nome, telefone, ignorarId) {
  const n = normaliza(nome); const t = soDigitos(telefone);
  const porNome = state.clientes.find((c) => c.id !== ignorarId && normaliza(c.nome) === n);
  if (porNome) return { cliente: porNome, motivo: 'nome' };
  if (t.length >= 8) {
    const porTel = state.clientes.find((c) => c.id !== ignorarId && soDigitos(c.telefone).endsWith(t.slice(-8)) && soDigitos(c.telefone).length >= 8);
    if (porTel) return { cliente: porTel, motivo: 'telefone' };
  }
  return null;
}
export async function salvarCliente(id, dados) {
  const d = { nome: dados.nome.trim(), nomeBusca: normaliza(dados.nome), telefone: soDigitos(dados.telefone), endereco: (dados.endereco || '').trim(), observacoes: (dados.observacoes || '').trim() };
  return backend.salvarCliente(id, d, state.me);
}

// ---------- ordens ----------
const CAMPOS = Object.keys(CAMPOS_OS);
export function limparCampos(c) {
  return {
    clienteId: c.clienteId || null,
    clienteNome: (c.clienteNome || '').trim(),
    telefone: soDigitos(c.telefone),
    veiculo: (c.veiculo || '').trim(),
    placa: (c.placa || '').trim().toUpperCase(),
    descricao: (c.descricao || '').trim(),
    endereco: (c.endereco || '').trim(),
    data: c.data,
    hora: c.hora || '',
    status: c.status || 'agendado',
    observacoes: (c.observacoes || '').trim(),
  };
}
export async function criarOrdem(campos, nota = '') {
  const c = limparCampos(campos);
  return backend.criarOrdem(c, state.me, nota);
}
function camposStatus(novo) {
  const p = { status: novo, statusPor: state.me, statusEm: NOW };
  if (novo === 'concluido') { p.concluidoPor = state.me; p.concluidoEm = NOW; } else { p.concluidoPor = null; p.concluidoEm = null; }
  return p;
}
export async function editarOrdem(antes, campos) {
  const c = limparCampos(campos);
  const alteracoes = [];
  for (const k of CAMPOS) {
    const a = antes[k] ?? ''; const b = c[k] ?? '';
    if (String(a) !== String(b)) alteracoes.push({ campo: k, de: a, para: b });
  }
  if (String(antes.clienteId || '') !== String(c.clienteId || '') && !alteracoes.find((x) => x.campo === 'clienteNome')) {
    alteracoes.push({ campo: 'clienteNome', de: antes.clienteNome, para: c.clienteNome });
  }
  if (!alteracoes.length) return false;
  let patch = { ...c };
  if (c.status !== antes.status) patch = { ...patch, ...camposStatus(c.status) };
  const soStatus = alteracoes.length === 1 && alteracoes[0].campo === 'status';
  await backend.atualizarOrdem(antes.id, antes.numero, patch, { tipo: soStatus ? 'status' : 'edicao', alteracoes }, state.me);
  return true;
}
export async function alterarStatus(os, novo) {
  if (os.status === novo) return false;
  await backend.atualizarOrdem(os.id, os.numero, camposStatus(novo), { tipo: 'status', alteracoes: [{ campo: 'status', de: os.status, para: novo }] }, state.me);
  return true;
}
export async function excluirOrdem(os) { await backend.excluirOrdem(os, state.me); }

// Garante cliente cadastrado para a OS (evita duplicados). Retorna clienteId.
export async function vincularCliente(campos, confirmarFn) {
  if (campos.clienteId) {
    const c = state.clientes.find((x) => x.id === campos.clienteId);
    if (c && normaliza(c.nome) === normaliza(campos.clienteNome)) {
      if (!c.telefone && soDigitos(campos.telefone)) await salvarCliente(c.id, { ...c, telefone: campos.telefone });
      return c.id;
    }
  }
  const dup = buscarClienteDuplicado(campos.clienteNome, campos.telefone);
  if (dup && dup.motivo === 'nome') {
    if (!dup.cliente.telefone && soDigitos(campos.telefone)) await salvarCliente(dup.cliente.id, { ...dup.cliente, telefone: campos.telefone });
    return dup.cliente.id;
  }
  if (dup && dup.motivo === 'telefone') {
    const usar = await confirmarFn(dup.cliente);
    if (usar) return dup.cliente.id;
  }
  return salvarCliente(null, { nome: campos.clienteNome, telefone: campos.telefone, endereco: campos.endereco });
}

// ---------- derivados p/ dashboard ----------
export function resumoHoje() {
  const h = hojeISO(); const todas = todasOrdens();
  const hoje = todas.filter((o) => o.data === h);
  const ini = new Date(); ini.setHours(0, 0, 0, 0);
  const fim7 = addDias(h, 7);
  return {
    hoje,
    agendadosHoje: hoje.filter((o) => o.status === 'agendado'),
    andamento: todas.filter((o) => o.status === 'andamento'),
    concluidosHoje: todas.filter((o) => o.status === 'concluido' && o.concluidoEm >= ini.getTime()),
    proximos: todas.filter((o) => o.data > h && o.data <= fim7 && o.status !== 'concluido'),
    proximosTodos: todas.filter((o) => o.data > h && o.status !== 'concluido'),
    atrasados: todas.filter((o) => o.data < h && o.status !== 'concluido'),
  };
}
export { fmtNumOS };
