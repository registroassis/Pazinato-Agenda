// Componentes de interface: ícones, cartões de OS, modais, toasts.
import { esc, STATUS, STATUS_KEYS, fmtTelefone, linkTel, linkWhats, rotuloDia, fmtNumOS } from './util.js';

const P = {
  home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  agenda: '<rect x="3" y="4.5" width="18" height="16.5" rx="2"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/>',
  os: '<rect x="5" y="3.5" width="14" height="18" rx="2"/><path d="M9 3.5V2h6v1.5M8.5 9h7M8.5 13h7M8.5 17h4"/>',
  clientes: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.6 3.2-5.5 6.5-5.5s5.9 1.9 6.5 5.5"/><circle cx="17" cy="9" r="2.6"/><path d="M16.5 14.6c2.6.2 4.4 1.9 5 4.9"/>',
  rel: '<path d="M4 20V4M4 20h16"/><rect x="7" y="11" width="3" height="6" rx=".5"/><rect x="12" y="7" width="3" height="10" rx=".5"/><rect x="17" y="13" width="3" height="4" rx=".5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  phone: '<path d="M5 3.5h3.2l1.6 4.2-2 1.3a11 11 0 0 0 5.2 5.2l1.3-2 4.2 1.6V17a2 2 0 0 1-2.2 2A15.5 15.5 0 0 1 3 5.7 2 2 0 0 1 5 3.5z"/>',
  whats: '<path d="M4 20l1.2-3.6A8 8 0 1 1 8 19z"/><path d="M9 9.2c.2 2.5 2.6 4.9 5.2 5.3l1-1.3-1.9-.9-.8.7c-.9-.4-1.6-1.1-2-2l.7-.8-.9-1.9z"/>',
  map: '<path d="M12 21s-6.5-6-6.5-11a6.5 6.5 0 0 1 13 0c0 5-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  left: '<path d="M15 5l-7 7 7 7"/>', right: '<path d="M9 5l7 7-7 7"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
  hist: '<path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1"/><path d="M3 4v4.5h4.5M12 8v4.5l3 1.8"/>',
  logout: '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 16l-4-4 4-4M6 12h10"/>',
  download: '<path d="M12 4v11M7 10.5l5 5 5-5M4.5 20h15"/>',
  print: '<path d="M7 9V3.5h10V9"/><rect x="3.5" y="9" width="17" height="8" rx="2"/><path d="M7 14.5h10V21H7z"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c.8-4 4-6 8-6s7.2 2 8 6"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15zM10 20.5a2.2 2.2 0 0 0 4 0"/>',
  filter: '<path d="M4 5h16l-6 7.5V19l-4 1.5v-8z"/>',
  truck: '<path d="M2.5 6.5h11v9h-11zM13.5 9.5h4l3 3.2v2.8h-7z"/><circle cx="6.5" cy="17" r="1.8"/><circle cx="17" cy="17" r="1.8"/>',
  alert: '<path d="M12 3.5 21.5 20h-19z"/><path d="M12 10v4.5M12 17.2v.3"/>',
  play: '<path d="M8 5.5v13l10-6.5z"/>',
  cal: '<rect x="3" y="4.5" width="18" height="16.5" rx="2"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4M7.5 13.5h2M11 13.5h2M14.5 13.5h2M7.5 17h2M11 17h2"/>',
  backup: '<path d="M4 7c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3z"/><path d="M4 7v5c0 1.7 3.6 3 8 3s8-1.3 8-3V7M4 12v5c0 1.7 3.6 3 8 3s8-1.3 8-3v-5"/>',
  wrench: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.8-3.8a6 6 0 0 1-7.9 7.9l-6.9 6.9a2.1 2.1 0 0 1-3-3l6.9-6.9a6 6 0 0 1 7.9-7.9z"/>',
  okc: '<circle cx="12" cy="12" r="9"/><path d="M8 12.3l2.7 2.7L16.2 9.5"/>',
  tractor: '<circle cx="7" cy="16.5" r="3.5"/><circle cx="18" cy="17.5" r="2.5"/><path d="M3.5 13V8h6l1.5 5M9.5 8V5h4l2 7.5M10.5 16.5h5M15.5 12.5h4.5V15"/>',
  share: '<path d="M12 3.5v12M7.5 8 12 3.5 16.5 8M5 12.5V20h14v-7.5"/>',
};
export function ic(nome, cls = '') {
  return `<svg class="ic ${cls}" viewBox="0 0 24 24" aria-hidden="true">${P[nome] || ''}</svg>`;
}

export function pillStatus(s, extra = '') {
  const m = STATUS[s] || { label: s };
  return `<span class="pill st-${esc(s)} ${extra}">${esc(m.label)}</span>`;
}

// Cartão de OS usado em listas/agenda. opts: {mostrarData}
export function cardOS(o, opts = {}) {
  const tel = linkTel(o.telefone); const wa = linkWhats(o.telefone);
  const quando = [opts.mostrarData ? rotuloDia(o.data) : '', o.hora || (opts.mostrarData ? '' : 'Sem horário')].filter(Boolean).join(' · ');
  return `
  <article class="card-os st-borda-${esc(o.status)}" data-os="${esc(o.id)}">
    <button class="card-os-main" data-abrir="${esc(o.id)}" aria-label="Abrir OS ${fmtNumOS(o.numero)}">
      <div class="card-os-top">
        <span class="card-os-hora">${o.hora ? ic('clock') + esc(quando) : esc(quando || 'Sem horário')}</span>
        <span class="card-os-num">OS ${fmtNumOS(o.numero)}${o._pendente ? ' <span class="sync" title="Aguardando sincronização">⟳</span>' : ''}</span>
      </div>
      <div class="card-os-cliente">${esc(o.clienteNome)}</div>
      ${o.veiculo || o.placa ? `<div class="card-os-veic">${ic('truck')}${esc(o.veiculo)}${o.placa ? ` <b class="placa">${esc(o.placa)}</b>` : ''}</div>` : ''}
      ${o.descricao ? `<div class="card-os-desc">${esc(o.descricao)}</div>` : ''}
    </button>
    <div class="card-os-acoes">
      <button class="pill-btn st-${esc(o.status)}" data-status="${esc(o.id)}" aria-label="Alterar status">${esc(STATUS[o.status]?.label || o.status)} ▾</button>
      <span class="grow"></span>
      ${tel ? `<a class="icon-btn" href="${esc(tel)}" aria-label="Ligar">${ic('phone')}</a>` : ''}
      ${wa ? `<a class="icon-btn wa" href="${esc(wa)}" target="_blank" rel="noopener" aria-label="WhatsApp">${ic('whats')}</a>` : ''}
    </div>
  </article>`;
}

// Linha compacta (painel inicial): horário à esquerda, status à direita
export function linhaOS(o, { data = false } = {}) {
  const trator = /trator|colhe|plantad|pulveri|m[aá]quina|deere|massey|valtra|new holland|case|retro|p[aá] carreg|escavad/i.test(o.veiculo || '');
  const d = new Date(o.data + 'T12:00');
  const caixa = data
    ? `<span class="lo-data"><b>${d.getDate()}</b><small>${['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'][d.getMonth()]}</small></span>`
    : `<span class="lo-hora">${o.hora ? esc(o.hora) : '<small>Sem<br>horário</small>'}</span>`;
  return `<div class="linha-os" data-os="${esc(o.id)}">
    <button class="lo-main" data-abrir="${esc(o.id)}">
      ${caixa}
      <span class="lo-info">
        <b>${esc(o.clienteNome)}</b>
        ${o.veiculo || o.placa ? `<span class="lo-l">${ic(trator ? 'tractor' : 'truck')}<span>${esc(o.veiculo)}${o.placa ? ` · ${esc(o.placa)}` : ''}</span></span>` : ''}
        ${o.descricao ? `<span class="lo-l">${ic('wrench')}<span>${esc(o.descricao)}</span></span>` : ''}
        ${data && o.hora ? `<span class="lo-l">${ic('clock')}<span>${esc(o.hora)}</span></span>` : ''}
      </span>
    </button>
    <button class="lo-st st-${esc(o.status)}" data-status="${esc(o.id)}">${ic(o.status === 'concluido' ? 'okc' : o.status === 'andamento' ? 'play' : 'cal')}<span>${esc(o.status === 'andamento' ? 'Andamento' : STATUS[o.status]?.label || o.status)}</span></button>
  </div>`;
}

export function listaDoDia(ordens, opts = {}) {
  const com = ordens.filter((o) => o.hora).sort((a, b) => (a.hora < b.hora ? -1 : a.hora > b.hora ? 1 : a.numero - b.numero));
  const sem = ordens.filter((o) => !o.hora).sort((a, b) => a.numero - b.numero);
  if (!ordens.length) return `<div class="vazio">${opts.vazio || 'Nenhum atendimento para este dia.'}</div>`;
  return `${com.length ? `<div class="lista">${com.map((o) => cardOS(o)).join('')}</div>` : ''}
    ${sem.length ? `<h3 class="sec-titulo">Sem horário definido <span class="badge">${sem.length}</span></h3><div class="lista">${sem.map((o) => cardOS(o)).join('')}</div>` : ''}`;
}

// ---------- modais / folhas ----------
const raiz = () => document.getElementById('modal-root');
export function abrirModal(html, { onMount, classe = '' } = {}) {
  return new Promise((resolve) => {
    const wrap = document.createElement('div');
    wrap.className = 'modal-wrap';
    wrap.innerHTML = `<div class="modal-fundo"></div><div class="modal ${classe}" role="dialog" aria-modal="true">${html}</div>`;
    raiz().appendChild(wrap);
    requestAnimationFrame(() => wrap.classList.add('on'));
    const fechar = (v) => {
      wrap.classList.remove('on');
      setTimeout(() => wrap.remove(), 180);
      document.removeEventListener('keydown', esc_);
      resolve(v);
    };
    const esc_ = (e) => { if (e.key === 'Escape') fechar(null); };
    document.addEventListener('keydown', esc_);
    wrap.querySelector('.modal-fundo').onclick = () => fechar(null);
    wrap.querySelectorAll('[data-fechar]').forEach((b) => (b.onclick = () => fechar(null)));
    onMount && onMount(wrap.querySelector('.modal'), fechar);
  });
}
export function confirmar(titulo, texto, { ok = 'Confirmar', perigo = false, cancelar = 'Cancelar' } = {}) {
  return abrirModal(`
    <h2 class="modal-titulo">${esc(titulo)}</h2>
    <p class="modal-texto">${texto}</p>
    <div class="modal-botoes">
      <button class="btn btn-sec" data-fechar>${esc(cancelar)}</button>
      <button class="btn ${perigo ? 'btn-perigo' : 'btn-pri'}" data-ok>${esc(ok)}</button>
    </div>`, { onMount: (m, fechar) => { m.querySelector('[data-ok]').onclick = () => fechar(true); } }).then((v) => v === true);
}
export function escolherStatus(atual) {
  return abrirModal(`
    <h2 class="modal-titulo">Alterar status</h2>
    <div class="status-opcoes">
      ${STATUS_KEYS.map((s) => `<button class="status-opcao st-${s} ${s === atual ? 'atual' : ''}" data-s="${s}">
        <span class="dot"></span>${esc(STATUS[s].label)}${s === atual ? ' <small>(atual)</small>' : ''}</button>`).join('')}
    </div>
    <button class="btn btn-sec bloco" data-fechar>Cancelar</button>`, {
    classe: 'folha',
    onMount: (m, fechar) => m.querySelectorAll('[data-s]').forEach((b) => (b.onclick = () => fechar(b.dataset.s))),
  });
}

let toastT;
export function toast(msg, tipo = 'ok') {
  let el = document.getElementById('toast');
  el.className = `toast on ${tipo}`; el.textContent = msg;
  clearTimeout(toastT); toastT = setTimeout(() => (el.className = 'toast'), 2800);
}

export function telefoneHtml(v) {
  const t = linkTel(v);
  return t ? `<a href="${esc(t)}">${esc(fmtTelefone(v))}</a>` : '—';
}

export function msgErro(e) {
  const c = (e && e.code) || '';
  if (c.includes('invalid-credential') || c.includes('wrong-password') || c.includes('user-not-found') || c.includes('invalid-email')) return 'E-mail ou senha incorretos.';
  if (c.includes('too-many-requests')) return 'Muitas tentativas. Aguarde alguns minutos e tente novamente.';
  if (c.includes('network')) return 'Sem conexão com a internet.';
  if (c.includes('permission-denied')) return 'Acesso negado pelas regras de segurança.';
  if (c.includes('weak-password')) return 'A nova senha precisa ter pelo menos 6 caracteres.';
  return (e && e.message) || 'Ocorreu um erro.';
}
