// Utilitários gerais: escape, datas, feriados, telefone, status.

export const NOW = Symbol('NOW'); // marcador de "data/hora do servidor"

export function esc(v) {
  if (v === null || v === undefined) return '';
  return String(v)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

export function normaliza(s) {
  return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '')
    .toLowerCase().replace(/\s+/g, ' ').trim();
}

export const soDigitos = (s) => String(s || '').replace(/\D/g, '');

// ---------- Status ----------
export const STATUS = {
  agendado: { label: 'Agendado', cor: 'var(--st-agendado)', emoji: '🟠' },
  andamento: { label: 'Em andamento', cor: 'var(--st-andamento)', emoji: '🔵' },
  concluido: { label: 'Concluído', cor: 'var(--st-concluido)', emoji: '🟢' },
};
export const STATUS_KEYS = ['agendado', 'andamento', 'concluido'];
export const statusLabel = (s) => (STATUS[s] ? STATUS[s].label : s || '—');

// ---------- Datas (sempre no fuso local, datas como 'AAAA-MM-DD') ----------
const pad = (n, l = 2) => String(n).padStart(l, '0');
export function isoDate(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
export function hojeISO() { return isoDate(new Date()); }
export function parseISO(s) { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); }
export function addDias(s, n) { const d = parseISO(s); d.setDate(d.getDate() + n); return isoDate(d); }
export function addMeses(s, n) { const d = parseISO(s); d.setDate(1); d.setMonth(d.getMonth() + n); return isoDate(d); }
export function inicioSemana(s) { const d = parseISO(s); d.setDate(d.getDate() - d.getDay()); return isoDate(d); } // domingo
export function ultimoDiaMes(ym) { const [y, m] = ym.split('-').map(Number); return `${ym}-${pad(new Date(y, m, 0).getDate())}`; }

export const MESES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
export const DIAS = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
export const DIAS_CURTO = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

export function fmtData(s) { if (!s) return '—'; const [y, m, d] = s.split('-'); return `${d}/${m}/${y}`; }
export function fmtDataLonga(s) {
  const d = parseISO(s);
  return `${DIAS[d.getDay()]}, ${d.getDate()} de ${MESES[d.getMonth()].toLowerCase()} de ${d.getFullYear()}`;
}
export function fmtMs(ms) {
  if (!ms) return '—';
  const d = new Date(ms);
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} às ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
export function rotuloDia(s) {
  const h = hojeISO();
  if (s === h) return 'Hoje';
  if (s === addDias(h, 1)) return 'Amanhã';
  if (s === addDias(h, -1)) return 'Ontem';
  const d = parseISO(s);
  return `${DIAS_CURTO[d.getDay()]}, ${fmtData(s)}`;
}

// ---------- Feriados nacionais (apenas informativos; nada é bloqueado) ----------
function pascoa(ano) {
  const a = ano % 19, b = Math.floor(ano / 100), c = ano % 100, d = Math.floor(b / 4), e = b % 4;
  const f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451);
  const mes = Math.floor((h + l - 7 * m + 114) / 31), dia = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(ano, mes - 1, dia);
}
const cacheFeriados = {};
export function feriadosAno(ano) {
  if (cacheFeriados[ano]) return cacheFeriados[ano];
  const f = {
    [`${ano}-01-01`]: 'Confraternização Universal',
    [`${ano}-04-21`]: 'Tiradentes',
    [`${ano}-05-01`]: 'Dia do Trabalho',
    [`${ano}-09-07`]: 'Independência do Brasil',
    [`${ano}-10-12`]: 'Nossa Senhora Aparecida',
    [`${ano}-11-02`]: 'Finados',
    [`${ano}-11-15`]: 'Proclamação da República',
    [`${ano}-11-20`]: 'Consciência Negra',
    [`${ano}-12-25`]: 'Natal',
  };
  const p = isoDate(pascoa(ano));
  f[addDias(p, -48)] = 'Carnaval';
  f[addDias(p, -47)] = 'Carnaval';
  f[addDias(p, -2)] = 'Sexta-feira Santa';
  f[p] = 'Páscoa';
  f[addDias(p, 60)] = 'Corpus Christi';
  cacheFeriados[ano] = f;
  return f;
}
export function feriado(s) { return feriadosAno(Number(s.slice(0, 4)))[s] || null; }

// ---------- Telefone ----------
export function fmtTelefone(v) {
  let d = soDigitos(v);
  if (d.length > 11 && d.startsWith('55')) d = d.slice(2);
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return v || '';
}
export function mascaraTelefone(v) {
  const d = soDigitos(v).slice(0, 11);
  if (d.length <= 2) return d.length ? `(${d}` : '';
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
}
export function linkTel(v) { const d = soDigitos(v); return d ? `tel:${d.length <= 11 ? '+55' + d : '+' + d}` : null; }
export function linkWhats(v) {
  let d = soDigitos(v);
  if (!d) return null;
  if (d.length <= 11) d = '55' + d;
  return `https://wa.me/${d}`;
}
export function linkMapa(endereco) {
  return endereco ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(endereco)}` : null;
}

export const fmtNumOS = (n) => String(n || 0).padStart(6, '0');

// Ordenação de OS dentro de um dia: com horário primeiro (cronológico), depois sem horário.
export function ordenaPorHorario(a, b) {
  if (a.data !== b.data) return a.data < b.data ? -1 : 1;
  if (a.hora && b.hora) return a.hora < b.hora ? -1 : a.hora > b.hora ? 1 : a.numero - b.numero;
  if (a.hora) return -1;
  if (b.hora) return 1;
  return a.numero - b.numero;
}

export function debounce(fn, ms) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

export const CAMPOS_OS = {
  clienteNome: 'Cliente', telefone: 'Telefone', veiculo: 'Veículo/máquina', placa: 'Placa',
  descricao: 'Serviço', endereco: 'Endereço/local', data: 'Data', hora: 'Horário', status: 'Status', observacoes: 'Observações',
};
export function fmtValorCampo(campo, v) {
  if (v === null || v === undefined || v === '') return '(vazio)';
  if (campo === 'data') return fmtData(v);
  if (campo === 'status') return statusLabel(v);
  if (campo === 'telefone') return fmtTelefone(v);
  return String(v);
}
