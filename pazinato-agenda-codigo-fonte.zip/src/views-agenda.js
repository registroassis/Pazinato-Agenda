// Telas: Início (dashboard) e Agenda (dia / semana / mês).
import { esc, hojeISO, addDias, addMeses, inicioSemana, parseISO, MESES, DIAS_CURTO, fmtDataLonga, fmtData, feriado, rotuloDia, ultimoDiaMes, STATUS_KEYS, ordenaPorHorario, isoDate, fmtNumOS, statusLabel } from './util.js';
import { state, resumoHoje, garantirMes, garantirPeriodo, ordensNoPeriodo, janelaPronta } from './store.js';
import { ic, cardOS, listaDoDia, linhaOS, abrirModal } from './ui.js';
import { go } from './router.js';

// ================= INÍCIO =================
const FLOCO = '<svg viewBox="0 0 100 100" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="7" stroke-linecap="round">' +
  [0, 60, 120].map((r) => `<g transform="rotate(${r} 50 50)"><path d="M50 6v88"/><path d="M50 22l-10-10M50 22l10-10M50 78l-10 10M50 78l10 10M50 36l-14-12M50 36l14-12M50 64l-14 12M50 64l14 12"/></g>`).join('') + '</g></svg>';
export const telaInicio = {
  titulo: 'Início', fab: false, home: true,
  mount(el) { this.el = el; this.update(); },
  update() {
    const r = resumoHoje(); const h = hojeISO(); const cfg = window.APP_CONFIG || {};
    const fer = feriado(h);
    const carregando = !janelaPronta('p') || !janelaPronta('m:' + h.slice(0, 7));
    const saud = (() => { const x = new Date().getHours(); return x < 12 ? 'Bom dia' : x < 18 ? 'Boa tarde' : 'Boa noite'; })();
    const prox = [...r.hoje.filter((o) => o.status !== 'concluido'), ...r.proximosTodos].sort(ordenaPorHorario)[0];
    const hojeOrd = [...r.hoje].sort(ordenaPorHorario);
    const outrosAnd = r.andamento.filter((o) => o.data !== h).sort(ordenaPorHorario);
    const alertas = r.atrasados.length;
    this.el.innerHTML = `
      <section class="home-hero">
        <div class="hh-flocos"><i class="f1">${FLOCO}</i><i class="f2">${FLOCO}</i><i class="f3">${FLOCO}</i></div>
        <div class="hh-raios"></div>
        <div class="hh-topo">
          <span class="grow"></span>
          <a class="hh-sino" href="#/os?p=atrasados" aria-label="Avisos">${ic('bell')}${alertas ? `<b>${alertas}</b>` : ''}</a>
          <button class="hh-user" data-menu-user>${ic('user')}<span>${esc(state.me ? state.me.pessoa : '')} ▾</span></button>
        </div>
        <img class="hh-logo" src="${esc(cfg.logoHorizontal || cfg.logo || 'assets/logo.png')}" alt="${esc(cfg.nomeEmpresa || '')}">
        <p class="hh-saud">${esc(saud)}, <b>${esc(state.me ? state.me.pessoa : '')}</b> · ${esc(fmtDataLonga(h))}${fer ? ` · <span class="tag-feriado peq">${esc(fer)}</span>` : ''}</p>
        <svg class="hh-onda" viewBox="0 0 400 40" preserveAspectRatio="none" aria-hidden="true"><path d="M0 26 C 90 4, 170 44, 260 22 S 370 8, 400 18 V40 H0z"/></svg>
      </section>
      <div class="home-corpo">
        ${prox ? `<a class="hh-destaque" href="#/os/${esc(prox.id)}">
            <span class="hd-ic">${ic('cal')}</span>
            <span class="hd-txt"><small>OS nº</small><b>${fmtNumOS(prox.numero)}</b></span>
            <span class="hd-st st-${esc(prox.status)}">${ic(prox.status === 'andamento' ? 'play' : 'cal')}<span>${esc(prox.status === 'andamento' ? 'Andamento' : statusLabel(prox.status))}</span>${ic('right')}</span>
            <span class="hd-info"><small>Próximo atendimento</small> ${esc(prox.clienteNome)} · ${esc(rotuloDia(prox.data))}${prox.hora ? ' às ' + esc(prox.hora) : ''}</span>
          </a>` : `<div class="hh-destaque vazio-d"><span class="hd-ic">${ic('okc')}</span><span class="hd-txt"><small>Tudo em dia</small><b class="peq">Nenhum atendimento pendente</b></span></div>`}
        <div class="stats">
          ${stat('Agendados', r.agendadosHoje.length, 'agendado', 'cal', '#/agenda?v=dia&d=' + h, 'hoje')}
          ${stat('Em andamento', r.andamento.length, 'andamento', 'wrench', '#/os?p=andamento')}
          ${stat('Concluídos', r.concluidosHoje.length, 'concluido', 'okc', '#/os?p=concluidoshoje', 'hoje')}
          ${stat('Pendentes', r.atrasados.length, 'pendente', 'clock', '#/os?p=atrasados', 'atrasados')}
        </div>
        <button class="btn-nova" data-nova><span class="bn-mais">${ic('plus')}</span><span>Nova Ordem de Serviço</span>${ic('right')}</button>
        ${alertas ? `<a class="alerta" href="#/os?p=atrasados">${ic('alert')}<span><b>${alertas}</b> serviço(s) com data passada ainda não concluído(s).</span>${ic('right')}</a>` : ''}
        <section class="painel-h">
          <header>${ic('cal')}<h2>Serviços de hoje</h2><a href="#/agenda?v=dia&d=${h}">Ver todos ${ic('right')}</a></header>
          ${carregando ? '<div class="carregando">Carregando…</div>' : hojeOrd.length ? hojeOrd.map((o) => linhaOS(o)).join('') : '<div class="ph-vazio">Nenhum atendimento para hoje.</div>'}
        </section>
        ${outrosAnd.length ? `<section class="painel-h">
          <header>${ic('wrench')}<h2>Em andamento de outros dias</h2></header>
          ${outrosAnd.map((o) => linhaOS(o, { data: true })).join('')}</section>` : ''}
        <section class="painel-h">
          <header>${ic('hist')}<h2>Próximos atendimentos</h2><a href="#/agenda?v=mes&d=${h}">Ver calendário ${ic('right')}</a></header>
          ${r.proximosTodos.length ? r.proximosTodos.sort(ordenaPorHorario).slice(0, 6).map((o) => linhaOS(o, { data: true })).join('') : '<div class="ph-vazio">Nenhum atendimento futuro agendado.</div>'}
        </section>
      </div>`;
    this.el.querySelector('[data-nova]').onclick = () => go('#/os/nova');
    this.el.querySelector('[data-menu-user]').onclick = () => menuUsuario();
  },
};
function stat(rotulo, n, tipo, icone, href, sub) {
  return `<a class="stat stat-${tipo}" href="${href}"><span class="stat-ic">${ic(icone)}</span><b>${n}</b><span class="stat-rot">${esc(rotulo)}</span>${sub ? `<small>${esc(sub)}</small>` : ''}<i class="stat-barra"></i></a>`;
}
function menuUsuario() {
  abrirModal(`
    <h2 class="modal-titulo">${esc(state.me ? state.me.pessoa : '')}</h2>
    <div class="menu-lista">
      <button data-a="trocar">${ic('user')}<span>Trocar usuário</span></button>
      <a href="#/os" data-fechar>${ic('search')}<span>Pesquisar ordens de serviço</span></a>
      <a href="#/historico" data-fechar>${ic('hist')}<span>Histórico de alterações</span></a>
      <a href="#/config" data-fechar>${ic('gear')}<span>Configurações e backup</span></a>
    </div>
    <button class="btn btn-sec bloco" data-fechar>Fechar</button>`, {
    classe: 'folha',
    onMount: (m, fechar) => {
      m.querySelectorAll('a[data-fechar]').forEach((a) => (a.onclick = () => fechar(null)));
      m.querySelector('[data-a=trocar]').onclick = () => { fechar(null); window.__trocarPessoa(); };
    },
  });
}

// ================= AGENDA =================
export const telaAgenda = {
  titulo: 'Agenda', fab: true,
  mount(el, params, q) {
    this.el = el;
    this.v = ['dia', 'semana', 'mes'].includes(q.get('v')) ? q.get('v') : 'dia';
    this.d = /^\d{4}-\d{2}-\d{2}$/.test(q.get('d') || '') ? q.get('d') : hojeISO();
    this.update();
  },
  nav(v, d) { go(`#/agenda?v=${v}&d=${d}`, true); },
  update() {
    const { v, d } = this;
    let periodo;
    if (v === 'dia') periodo = [d, d];
    else if (v === 'semana') { const i = inicioSemana(d); periodo = [i, addDias(i, 6)]; }
    else { const ym = d.slice(0, 7); const i = inicioSemana(ym + '-01'); periodo = [i, addDias(i, 41)]; }
    garantirPeriodo(periodo[0], periodo[1]);
    const ordens = ordensNoPeriodo(periodo[0], periodo[1]);
    const pronto = janelaPronta('m:' + d.slice(0, 7));
    const passo = v === 'dia' ? 1 : v === 'semana' ? 7 : 0;
    const ant = v === 'mes' ? addMeses(d, -1) : addDias(d, -passo);
    const prox = v === 'mes' ? addMeses(d, 1) : addDias(d, passo);
    let titulo;
    if (v === 'dia') titulo = rotuloDia(d) === 'Hoje' || rotuloDia(d) === 'Amanhã' || rotuloDia(d) === 'Ontem' ? `${rotuloDia(d)} · ${fmtData(d)}` : fmtDataLonga(d);
    else if (v === 'semana') titulo = `${fmtData(periodo[0]).slice(0, 5)} a ${fmtData(periodo[1])}`;
    else { const x = parseISO(d); titulo = `${MESES[x.getMonth()]} de ${x.getFullYear()}`; }

    this.el.innerHTML = `
      <div class="seg" role="tablist">
        ${[['dia', 'Dia'], ['semana', 'Semana'], ['mes', 'Mês']].map(([k, l]) => `<button class="seg-b ${v === k ? 'on' : ''}" data-v="${k}">${l}</button>`).join('')}
      </div>
      <div class="agenda-nav">
        <button class="icon-btn grande" data-ir="${ant}" aria-label="Anterior">${ic('left')}</button>
        <button class="agenda-titulo" data-escolher>${esc(titulo)} ▾</button>
        <button class="icon-btn grande" data-ir="${prox}" aria-label="Próximo">${ic('right')}</button>
      </div>
      <div class="agenda-atalhos">
        <button class="chip" data-ir="${hojeISO()}">Hoje</button>
        ${v === 'dia' ? `<button class="chip" data-ir="${addDias(hojeISO(), 1)}">Amanhã</button>` : ''}
        <label class="chip chip-input">${ic('cal')} Ir para data<input type="date" data-data value="${d}"></label>
      </div>
      <div class="agenda-corpo">${!pronto ? '<div class="carregando">Carregando…</div>' : v === 'dia' ? this.dia(d, ordens) : v === 'semana' ? this.semana(periodo[0], ordens) : this.mes(d, ordens)}</div>`;
    this.el.querySelectorAll('[data-v]').forEach((b) => (b.onclick = () => this.nav(b.dataset.v, d)));
    this.el.querySelectorAll('[data-ir]').forEach((b) => (b.onclick = () => this.nav(v, b.dataset.ir)));
    this.el.querySelectorAll('[data-dia]').forEach((b) => (b.onclick = () => this.nav('dia', b.dataset.dia)));
    const inp = this.el.querySelector('[data-data]');
    inp.onchange = () => inp.value && this.nav(v, inp.value);
    this.el.querySelector('[data-escolher]').onclick = () => this.escolherMesAno();
    this.el.querySelectorAll('[data-novo-dia]').forEach((b) => (b.onclick = () => go('#/os/nova?d=' + b.dataset.novoDia)));
  },
  dia(d, ordens) {
    const fer = feriado(d); const x = parseISO(d);
    const fds = x.getDay() === 0 || x.getDay() === 6;
    return `${fer || fds ? `<div class="info-dia">${fer ? `<span class="tag-feriado">${esc(fer)}</span>` : ''}${fds ? `<span class="tag-fds">${x.getDay() === 0 ? 'Domingo' : 'Sábado'}</span>` : ''}</div>` : ''}
      ${listaDoDia(ordens.filter((o) => o.data === d))}
      <button class="btn btn-sec bloco mt" data-novo-dia="${d}">${ic('plus')} Agendar neste dia</button>`;
  },
  semana(ini, ordens) {
    let html = '';
    for (let i = 0; i < 7; i++) {
      const dd = addDias(ini, i); const lista = ordens.filter((o) => o.data === dd).sort(ordenaPorHorario);
      const fer = feriado(dd); const x = parseISO(dd);
      html += `<section class="semana-dia ${dd === hojeISO() ? 'hoje' : ''}">
        <header><button class="semana-cab" data-dia="${dd}"><b>${DIAS_CURTO[x.getDay()]}</b> ${fmtData(dd).slice(0, 5)}
          ${fer ? `<span class="tag-feriado peq">${esc(fer)}</span>` : ''}</button>
          <span class="badge">${lista.length}</span>
          <button class="icon-btn" data-novo-dia="${dd}" aria-label="Agendar neste dia">${ic('plus')}</button></header>
        ${lista.length ? `<div class="lista">${lista.map((o) => cardOS(o)).join('')}</div>` : '<div class="vazio peq">Sem atendimentos</div>'}
      </section>`;
    }
    return html;
  },
  mes(d, ordens) {
    const ym = d.slice(0, 7); const ini = inicioSemana(ym + '-01'); const h = hojeISO();
    let cel = '';
    for (let i = 0; i < 42; i++) {
      const dd = addDias(ini, i);
      if (i === 35 && dd.slice(0, 7) !== ym) break;
      const lista = ordens.filter((o) => o.data === dd); const fer = feriado(dd);
      const cont = Object.fromEntries(STATUS_KEYS.map((s) => [s, lista.filter((o) => o.status === s).length]));
      const fora = dd.slice(0, 7) !== ym; const dow = parseISO(dd).getDay();
      cel += `<button class="cal-dia ${fora ? 'fora' : ''} ${dd === h ? 'hoje' : ''} ${dd === d ? 'sel' : ''} ${fer ? 'feriado' : ''} ${dow === 0 || dow === 6 ? 'fds' : ''}" data-dia="${dd}" title="${esc(fer || '')}">
        <span class="cal-n">${Number(dd.slice(8))}</span>
        ${lista.length ? `<span class="cal-qtd">${lista.length}</span><span class="cal-dots">${STATUS_KEYS.map((s) => (cont[s] ? `<i class="dot st-${s}"></i>` : '')).join('')}</span>` : ''}
        ${fer ? '<span class="cal-fer"></span>' : ''}
      </button>`;
    }
    const doMes = ordens.filter((o) => o.data.slice(0, 7) === ym);
    const tot = Object.fromEntries(STATUS_KEYS.map((s) => [s, doMes.filter((o) => o.status === s).length]));
    const feriadosMes = Object.entries(Object.fromEntries(Array.from({ length: 31 }, (_, i) => { const dd = `${ym}-${String(i + 1).padStart(2, '0')}`; return [dd, dd <= ultimoDiaMes(ym) ? feriado(dd) : null]; }))).filter(([, n]) => n);
    return `<div class="cal">
        ${DIAS_CURTO.map((x) => `<div class="cal-sem">${x}</div>`).join('')}
        ${cel}
      </div>
      <div class="cal-legenda">
        <span><i class="dot st-agendado"></i> Agendado (${tot.agendado})</span>
        <span><i class="dot st-andamento"></i> Em andamento (${tot.andamento})</span>
        <span><i class="dot st-concluido"></i> Concluído (${tot.concluido})</span>
      </div>
      <p class="cal-total">${doMes.length} serviço(s) neste mês</p>
      ${feriadosMes.length ? `<div class="cal-feriados">${feriadosMes.map(([dd, n]) => `<button class="chip" data-dia="${dd}">${fmtData(dd).slice(0, 5)} · ${esc(n)}</button>`).join('')}</div>` : ''}`;
  },
  escolherMesAno() {
    const x = parseISO(this.d); const ano = x.getFullYear();
    import('./ui.js').then(({ abrirModal }) => abrirModal(`
      <h2 class="modal-titulo">Escolher mês e ano</h2>
      <div class="ano-nav"><button class="icon-btn grande" data-a="-1">${ic('left')}</button><b data-ano>${ano}</b><button class="icon-btn grande" data-a="1">${ic('right')}</button></div>
      <div class="meses-grid">${MESES.map((m, i) => `<button class="chip ${i === x.getMonth() ? 'on' : ''}" data-m="${i}">${m.slice(0, 3)}</button>`).join('')}</div>
      <button class="btn btn-sec bloco" data-fechar>Cancelar</button>`, {
      onMount: (m, fechar) => {
        let a = ano; const lb = m.querySelector('[data-ano]');
        m.querySelectorAll('[data-a]').forEach((b) => (b.onclick = () => { a += Number(b.dataset.a); lb.textContent = a; }));
        m.querySelectorAll('[data-m]').forEach((b) => (b.onclick = () => {
          fechar(); const dd = isoDate(new Date(a, Number(b.dataset.m), 1));
          this.nav(this.v === 'dia' ? 'mes' : this.v, dd);
        }));
      },
    }));
  },
};
