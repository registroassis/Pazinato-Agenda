// Telas: Clientes (lista, cadastro, histórico do cliente).
import { esc, normaliza, soDigitos, fmtTelefone, mascaraTelefone, linkTel, linkWhats, fmtData, fmtMs, hojeISO, ordenaPorHorario, debounce } from './util.js';
import { state, garantirJanela, janelaPronta, ordensDaJanela, salvarCliente, buscarClienteDuplicado, backend, nomeUsuario } from './store.js';
import { ic, cardOS, abrirModal, confirmar, toast, msgErro } from './ui.js';
import { go } from './router.js';

export const telaClientes = {
  titulo: 'Clientes', fab: true,
  mount(el) {
    this.el = el; this.t = '';
    el.innerHTML = `
      <div class="busca">${ic('search')}<input type="search" data-b placeholder="Buscar cliente por nome ou telefone" autocomplete="off"></div>
      <button class="btn btn-sec bloco" data-novo>${ic('plus')} Cadastrar cliente</button>
      <div data-res></div>`;
    el.querySelector('[data-b]').oninput = debounce((e) => { this.t = e.target.value; this.update(); }, 120);
    el.querySelector('[data-novo]').onclick = async () => { const id = await formCliente(null); if (id) go('#/clientes/' + id); };
    this.update();
  },
  update() {
    const res = this.el.querySelector('[data-res]');
    if (!state.clientesCarregados) { res.innerHTML = '<div class="carregando">Carregando…</div>'; return; }
    const t = normaliza(this.t); const d = soDigitos(this.t);
    const l = state.clientes.filter((c) => !t || normaliza(c.nome).includes(t) || (d.length >= 3 && soDigitos(c.telefone).includes(d)));
    res.innerHTML = `<p class="muted cont">${l.length} cliente(s)</p>
      ${l.length ? `<div class="lista-simples">${l.slice(0, 300).map((c) => `
        <a class="item-cli" href="#/clientes/${esc(c.id)}">
          <span class="avatar">${esc((c.nome || '?').trim().charAt(0).toUpperCase())}</span>
          <span class="grow"><b>${esc(c.nome)}</b><small>${c.telefone ? esc(fmtTelefone(c.telefone)) : 'Sem telefone'}</small></span>
          ${ic('right', 'muted')}
        </a>`).join('')}</div>` : '<div class="vazio">Nenhum cliente encontrado.</div>'}`;
  },
};

export const telaCliente = {
  titulo: 'Cliente', voltar: true,
  mount(el, params) {
    this.el = el; this.id = params.id; this.key = 'c:' + this.id;
    garantirJanela(this.key, { clienteId: this.id });
    this.update();
  },
  update() {
    const c = state.clientes.find((x) => x.id === this.id);
    if (!state.clientesCarregados) { this.el.innerHTML = '<div class="carregando">Carregando…</div>'; return; }
    if (!c) { this.el.innerHTML = '<div class="vazio">Cliente não encontrado.</div>'; return; }
    document.querySelector('[data-titulo]').textContent = c.nome;
    const pronta = janelaPronta(this.key);
    const j = pronta ? ordensDaJanela(this.key) : [];
    const ordens = j.sort((a, b) => -ordenaPorHorario(a, b));
    const h = hojeISO();
    const passados = ordens.filter((o) => o.data <= h);
    const ultimo = passados[0];
    const tel = linkTel(c.telefone); const wa = linkWhats(c.telefone);
    this.el.innerHTML = `
      <div class="cli-cab"><span class="avatar grande">${esc(c.nome.charAt(0).toUpperCase())}</span>
        <div><h1>${esc(c.nome)}</h1><small class="muted">${c.telefone ? esc(fmtTelefone(c.telefone)) : 'Sem telefone'}</small></div></div>
      <div class="acoes-rapidas">
        ${tel ? `<a class="acao" href="${esc(tel)}">${ic('phone')}<span>Ligar</span></a>` : `<span class="acao off">${ic('phone')}<span>Ligar</span></span>`}
        ${wa ? `<a class="acao wa" href="${esc(wa)}" target="_blank" rel="noopener">${ic('whats')}<span>WhatsApp</span></a>` : `<span class="acao off">${ic('whats')}<span>WhatsApp</span></span>`}
        <a class="acao" href="#/os/nova?cliente=${esc(c.id)}">${ic('plus')}<span>Nova OS</span></a>
      </div>
      <div class="cards-resumo dois">
        <div class="card-resumo"><span class="cr-num">${pronta ? ordens.length : '…'}</span><span class="cr-rot">Atendimentos</span></div>
        <div class="card-resumo"><span class="cr-num peq">${ultimo ? esc(fmtData(ultimo.data)) : '—'}</span><span class="cr-rot">Último atendimento</span></div>
      </div>
      <dl class="ficha">
        <div><dt>Nome</dt><dd>${esc(c.nome)}</dd></div>
        <div><dt>Telefone</dt><dd>${tel ? `<a href="${esc(tel)}">${esc(fmtTelefone(c.telefone))}</a>` : '—'}</dd></div>
        ${c.endereco ? `<div class="full"><dt>Endereço</dt><dd>${esc(c.endereco)}</dd></div>` : ''}
        ${c.observacoes ? `<div class="full"><dt>Observações</dt><dd class="pre">${esc(c.observacoes)}</dd></div>` : ''}
        <div class="full"><dt>Cadastrado por</dt><dd>${esc(nomeUsuario(c.criadoPor))} · ${esc(fmtMs(c.criadoEm))}</dd></div>
      </dl>
      <div class="botoes-ficha"><button class="btn btn-sec" data-editar>${ic('edit')} Editar cliente</button>
        <button class="btn btn-perigo-sec" data-excluir>${ic('trash')} Excluir</button></div>
      <h3 class="sec-titulo">Histórico de serviços</h3>
      ${!pronta ? '<div class="carregando">Carregando…</div>' : ordens.length ? `<div class="lista">${ordens.map((o) => cardOS(o, { mostrarData: true })).join('')}</div>` : '<div class="vazio">Nenhuma OS para este cliente.</div>'}`;
    this.el.querySelector('[data-editar]').onclick = () => formCliente(c);
    this.el.querySelector('[data-excluir]').onclick = async () => {
      if (ordens.length) { toast('Este cliente possui OS vinculadas e não pode ser excluído.', 'erro'); return; }
      if (!(await confirmar('Excluir cliente?', `O cadastro de <b>${esc(c.nome)}</b> será excluído.`, { ok: 'Excluir', perigo: true }))) return;
      try { await backend.excluirCliente(c.id); toast('Cliente excluído'); go('#/clientes', true); } catch (e) { toast(msgErro(e), 'erro'); }
    };
  },
};

// Formulário de cliente em modal. Retorna id salvo ou null.
export function formCliente(c) {
  return abrirModal(`
    <h2 class="modal-titulo">${c ? 'Editar cliente' : 'Novo cliente'}</h2>
    <form class="form" novalidate>
      <label class="campo req"><span class="rot">Nome *</span><input name="nome" required value="${esc(c ? c.nome : '')}"></label>
      <label class="campo"><span class="rot">Telefone / WhatsApp</span><input name="telefone" type="tel" inputmode="tel" value="${esc(c ? mascaraTelefone(c.telefone) : '')}" placeholder="(00) 00000-0000"></label>
      <label class="campo"><span class="rot">Endereço</span><input name="endereco" value="${esc(c ? c.endereco : '')}"></label>
      <label class="campo"><span class="rot">Observações</span><textarea name="observacoes" rows="2">${esc(c ? c.observacoes : '')}</textarea></label>
      <p class="erro-msg" data-erro hidden></p>
      <div class="modal-botoes"><button type="button" class="btn btn-sec" data-fechar>Cancelar</button><button class="btn btn-pri" type="submit">Salvar</button></div>
    </form>`, {
    onMount: (m, fechar) => {
      const f = m.querySelector('form'); const er = m.querySelector('[data-erro]');
      f.telefone.oninput = () => (f.telefone.value = mascaraTelefone(f.telefone.value));
      setTimeout(() => f.nome.focus(), 50);
      f.onsubmit = async (e) => {
        e.preventDefault();
        const dados = { nome: f.nome.value, telefone: f.telefone.value, endereco: f.endereco.value, observacoes: f.observacoes.value };
        if (!dados.nome.trim()) { er.hidden = false; er.textContent = 'Informe o nome.'; return; }
        const dup = buscarClienteDuplicado(dados.nome, dados.telefone, c && c.id);
        if (dup) { er.hidden = false; er.innerHTML = `Já existe um cliente com este ${dup.motivo}: <a href="#/clientes/${esc(dup.cliente.id)}">${esc(dup.cliente.nome)}</a>.`; er.querySelector('a').onclick = () => fechar(null); return; }
        try { const id = await salvarCliente(c ? c.id : null, dados); toast('Cliente salvo'); fechar(id); } catch (e2) { er.hidden = false; er.textContent = msgErro(e2); }
      };
    },
  });
}
