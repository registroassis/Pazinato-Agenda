// Telas: Configurações, Perfil, Histórico geral, Login.
import { esc, fmtMs } from './util.js';
import { state, backend, quem, escolherPessoa } from './store.js';
import { ic, toast, msgErro, confirmar, abrirModal } from './ui.js';
import { timelineHtml } from './historico.js';
import { lerPrefs, salvarPrefs, pedirPermissao, permissao, suportado, mostrar } from './notify.js';

const CFG = () => window.APP_CONFIG || {};

export const telaConfig = {
  titulo: 'Configurações', voltar: true, estatico: true,
  mount(el) {
    this.el = el; const p = lerPrefs(); const cfg = CFG();
    const perm = permissao();
    el.innerHTML = `
      <a class="item-menu" href="#/perfil">${ic('user')}<span class="grow"><b>Usuário: ${esc(state.me ? state.me.pessoa : '')}</b><small>Trocar usuário · alterar senha da conta</small></span>${ic('right')}</a>
      <a class="item-menu" href="#/historico">${ic('hist')}<span class="grow"><b>Histórico de alterações</b><small>Auditoria de tudo que os sócios fizeram</small></span>${ic('right')}</a>
      <a class="item-menu" href="#/os">${ic('search')}<span class="grow"><b>Pesquisa e filtros de OS</b><small>Localizar qualquer ordem de serviço</small></span>${ic('right')}</a>

      <h3 class="sec-titulo">${ic('bell')} Notificações neste aparelho</h3>
      <div class="painel">
        ${!suportado() ? '<p class="muted">Este navegador não suporta notificações. No iPhone, instale o app na tela de início (iOS 16.4 ou superior) e abra por lá.</p>' : ''}
        <label class="switch-linha"><span>Ativar notificações</span><input type="checkbox" class="switch" data-p="ativo" ${p.ativo ? 'checked' : ''}></label>
        <div data-subprefs ${p.ativo ? '' : 'hidden'}>
          <label class="switch-linha"><span>Resumo diário da agenda</span><input type="checkbox" class="switch" data-p="resumoDiario" ${p.resumoDiario ? 'checked' : ''}></label>
          <label class="switch-linha"><span>Horário do resumo</span><input type="time" data-p="horaResumo" value="${esc(p.horaResumo)}"></label>
          <label class="switch-linha"><span>Incluir serviços em andamento</span><input type="checkbox" class="switch" data-p="andamento" ${p.andamento ? 'checked' : ''}></label>
          <label class="switch-linha"><span>Avisar serviços atrasados</span><input type="checkbox" class="switch" data-p="atrasados" ${p.atrasados ? 'checked' : ''}></label>
          <label class="switch-linha"><span>Lembrete antes do horário</span><select data-p="lembreteMin">
            ${[[0, 'Desligado'], [15, '15 min antes'], [30, '30 min antes'], [60, '1 hora antes'], [120, '2 horas antes']].map(([v, l]) => `<option value="${v}" ${Number(p.lembreteMin) === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
          <button class="btn btn-sec bloco" data-testar>${ic('bell')} Enviar notificação de teste</button>
        </div>
        <p class="muted peq">Permissão do aparelho: <b data-perm>${perm === 'granted' ? 'concedida' : perm === 'denied' ? 'bloqueada (libere nas configurações do navegador)' : perm === 'unsupported' ? 'não suportado' : 'ainda não solicitada'}</b>.
        Os avisos aparecem enquanto o app estiver aberto ou recém-utilizado.</p>
      </div>

      <h3 class="sec-titulo">${ic('backup')} Backup dos dados</h3>
      <div class="painel">
        <p class="muted">Os dados ficam no Firebase (nuvem do Google) e sincronizados entre os aparelhos. Recomenda-se baixar um backup completo uma vez por mês e guardar no computador ou Google Drive.</p>
        <button class="btn btn-pri bloco" data-backup>${ic('download')} Baixar backup completo (Excel + JSON)</button>
        <p class="muted peq" data-ult-backup>${localStorage.getItem('osapp_ult_backup') ? 'Último backup neste aparelho: ' + esc(fmtMs(Number(localStorage.getItem('osapp_ult_backup')))) : 'Nenhum backup baixado neste aparelho ainda.'}</p>
      </div>

      <h3 class="sec-titulo">${ic('clientes')} Usuários</h3>
      <div class="painel">${Object.values(state.usuarios).map((u) => `<div class="linha-u"><span class="avatar">${esc(u.nome.charAt(0).toUpperCase())}</span><span class="grow"><b>${esc(u.nome)}</b></span></div>`).join('')}
        <p class="muted peq">Login único: ${esc(state.user ? state.user.email : '')}. Os nomes ficam no arquivo config.js (campo "usuarios").</p></div>

      <h3 class="sec-titulo">Sobre</h3>
      <div class="painel"><p><b>${esc(cfg.nomeApp || '')}</b> · versão ${esc(window.APP_VERSAO || '')}</p>
        <p class="muted peq">Banco de dados: ${backend.nome === 'firebase' ? 'Firebase (Firestore) — projeto ' + esc((cfg.firebase || {}).projectId || '') : 'MODO TESTE LOCAL (dados só neste navegador)'}</p>
        <button class="btn btn-sec bloco" data-atualizar>Verificar atualização do app</button></div>

      <button class="btn btn-perigo-sec bloco mt" data-sair>${ic('logout')} Sair da conta</button>`;

    const sub = el.querySelector('[data-subprefs]');
    el.querySelectorAll('[data-p]').forEach((i) => (i.onchange = async () => {
      const np = lerPrefs(); const k = i.dataset.p;
      np[k] = i.type === 'checkbox' ? i.checked : k === 'lembreteMin' ? Number(i.value) : i.value;
      if (k === 'ativo' && i.checked) {
        const r = await pedirPermissao();
        el.querySelector('[data-perm]').textContent = r === 'granted' ? 'concedida' : r === 'denied' ? 'bloqueada' : r;
        if (r !== 'granted') { toast('Permissão de notificação não concedida.', 'erro'); i.checked = false; np.ativo = false; }
      }
      salvarPrefs(np); sub.hidden = !np.ativo;
    }));
    el.querySelector('[data-testar]').onclick = async () => { const ok = await mostrar(CFG().nomeApp || 'Teste', 'As notificações estão funcionando neste aparelho.', '#/config', 'teste'); toast(ok ? 'Notificação enviada' : 'Não foi possível notificar', ok ? 'ok' : 'erro'); };
    el.querySelector('[data-backup]').onclick = async (e) => {
      const b = e.currentTarget; b.disabled = true; b.textContent = 'Gerando backup…';
      try {
        const dados = await backend.exportarTudo();
        const m = await import('./export.js'); const r = await m.backupCompleto(dados);
        await m.salvarArquivo(r.xlsx, r.nomeXlsx); await new Promise((x) => setTimeout(x, 600)); await m.salvarArquivo(r.json, r.nomeJson);
        localStorage.setItem('osapp_ult_backup', String(Date.now()));
        el.querySelector('[data-ult-backup]').textContent = 'Último backup neste aparelho: ' + fmtMs(Date.now());
        toast(`Backup gerado: ${dados.ordens.length} OS, ${dados.clientes.length} clientes`);
      } catch (er) { toast(msgErro(er), 'erro'); }
      b.disabled = false; b.innerHTML = `${ic('download')} Baixar backup completo (Excel + JSON)`;
    };
    el.querySelector('[data-atualizar]').onclick = async () => {
      const reg = navigator.serviceWorker && (await navigator.serviceWorker.getRegistration());
      if (reg) { await reg.update(); toast('Verificado. Se houver versão nova, ela será aplicada ao reabrir.'); } else location.reload();
    };
    el.querySelector('[data-sair]').onclick = async () => { if (await confirmar('Sair?', 'Você precisará entrar com e-mail e senha novamente.', { ok: 'Sair' })) (window.__esquecerPessoa(), backend.logout()); };
  },
};

export const telaPerfil = {
  titulo: 'Usuário e senha', voltar: true, estatico: true,
  mount(el) {
    el.innerHTML = `
      <div class="painel">
        <h3 class="sec-titulo" style="margin-top:4px">Usuário atual</h3>
        <div class="linha-u"><span class="avatar grande">${esc((state.me ? state.me.pessoa : '?').charAt(0))}</span><span class="grow"><b style="font-size:20px">${esc(state.me ? state.me.pessoa : '')}</b><small>Conta de acesso: ${esc(state.user ? state.user.email : '')}</small></span></div>
        <button class="btn btn-pri bloco" data-trocar>Trocar usuário</button>
      </div>
      <form class="form mt" data-f2 novalidate>
        <h3 class="sec-titulo">Senha da conta (vale para os dois)</h3>
        <label class="campo"><span class="rot">Senha atual</span><input name="atual" type="password" autocomplete="current-password"></label>
        <label class="campo"><span class="rot">Nova senha (mín. 6 caracteres)</span><input name="nova" type="password" autocomplete="new-password"></label>
        <button class="btn btn-sec bloco" type="submit">Alterar senha</button>
      </form>`;
    el.querySelector('[data-trocar]').onclick = () => window.__trocarPessoa();
    el.querySelector('[data-f2]').onsubmit = async (e) => {
      e.preventDefault(); const f = e.target;
      if (f.nova.value.length < 6) return toast('A nova senha precisa ter 6+ caracteres', 'erro');
      try { await backend.trocarSenha(f.atual.value, f.nova.value); toast('Senha alterada'); f.reset(); } catch (er) { toast(msgErro(er), 'erro'); }
    };
  },
};

export const telaHistorico = {
  titulo: 'Histórico de alterações', voltar: true,
  mount(el) {
    this.el = el; this.l = null; this.socio = '';
    el.innerHTML = `<label class="campo"><span class="rot">Filtrar por sócio</span><select data-s><option value="">Todos</option>
      ${Object.values(state.usuarios).map((u) => `<option value="${esc(u.id)}">${esc(u.nome || u.email)}</option>`).join('')}</select></label>
      <p class="muted peq">Registros permanentes: não podem ser apagados nem alterados, nem mesmo ao editar ou excluir uma OS. Exibindo os 300 mais recentes.</p>
      <div data-res><div class="carregando">Carregando…</div></div>`;
    el.querySelector('[data-s]').onchange = (e) => { this.socio = e.target.value; this.update(); };
    this.unsub = backend.watchHistorico({ limite: 300 }, (l) => { this.l = l.sort((a, b) => (b.em || 0) - (a.em || 0)); this.update(); });
  },
  unmount() { this.unsub && this.unsub(); },
  update() {
    if (!this.l) return;
    const l = this.socio ? this.l.filter((h) => h.usuario && quem(h.usuario) === this.socio) : this.l;
    this.el.querySelector('[data-res]').innerHTML = timelineHtml(l, { mostrarOS: true });
  },
};

export function telaLogin(el, { erro } = {}) {
  const cfg = CFG();
  el.innerHTML = `
    <div class="login">
      <div class="login-marca"><img src="${esc(cfg.logoHorizontal || cfg.logo || 'assets/logo.png')}" alt="" class="login-logo" onerror="this.style.display='none'">
        <h1>${esc(cfg.nomeApp || '')}</h1><p>${esc(cfg.subtitulo || '')}</p></div>
      ${backend.nome === 'local' ? '<div class="aviso">MODO TESTE LOCAL — use pazinato@teste.com, senha <b>teste123</b>. Os dados ficam só neste navegador.</div>' : ''}
      <form class="form" novalidate>
        <label class="campo"><span class="rot">E-mail</span><input name="email" type="email" autocomplete="username" inputmode="email" required></label>
        <label class="campo"><span class="rot">Senha</span><input name="senha" type="password" autocomplete="current-password" required></label>
        <p class="erro-msg" data-erro ${erro ? '' : 'hidden'}>${esc(erro || '')}</p>
        <button class="btn btn-pri btn-grande bloco" type="submit">Entrar</button>
        <button class="btn btn-link bloco" type="button" data-esqueci>Esqueci minha senha</button>
      </form>
    </div>`;
  const f = el.querySelector('form'); const er = el.querySelector('[data-erro]');
  f.onsubmit = async (e) => {
    e.preventDefault(); er.hidden = true;
    const b = f.querySelector('[type=submit]'); b.disabled = true; b.textContent = 'Entrando…';
    try { await backend.login(f.email.value, f.senha.value); } catch (x) { er.hidden = false; er.textContent = msgErro(x); b.disabled = false; b.textContent = 'Entrar'; }
  };
  el.querySelector('[data-esqueci]').onclick = async () => {
    if (!f.email.value) { er.hidden = false; er.textContent = 'Digite seu e-mail acima e toque novamente em "Esqueci minha senha".'; return; }
    try { await backend.resetSenha(f.email.value); er.hidden = false; er.textContent = 'Se o e-mail estiver cadastrado, você receberá um link para criar nova senha.'; } catch (x) { er.hidden = false; er.textContent = msgErro(x); }
  };
}

// Login único: escolha de quem está usando
export function telaQuemUsa(el, pessoas, atual) {
  const cfg = CFG();
  return new Promise((resolve) => {
    el.innerHTML = `
      <div class="login">
        <div class="login-marca"><img src="${esc(cfg.logoHorizontal || cfg.logo || 'assets/logo.png')}" alt="" class="login-logo" onerror="this.style.display='none'">
          <h1>Quem está usando?</h1><p>Tudo o que for lançado ficará registrado no seu nome.</p></div>
        <div class="quem-lista">${pessoas.map((p) => `<button class="quem-btn ${p === atual ? 'atual' : ''}" data-p="${esc(p)}"><span class="avatar grande">${esc(p.charAt(0).toUpperCase())}</span><b>${esc(p)}</b></button>`).join('')}</div>
        <button class="btn btn-link bloco quem-sair" data-sair>Sair da conta</button>
      </div>`;
    el.querySelectorAll('[data-p]').forEach((b) => (b.onclick = () => resolve(b.dataset.p)));
    el.querySelector('[data-sair]').onclick = () => (window.__esquecerPessoa(), backend.logout());
  });
}
