// Telas: Lista/pesquisa de OS, Nova/Editar/Duplicar OS, Ficha da OS.
import {
  esc, hojeISO, addDias, fmtData, fmtMs, normaliza, soDigitos, STATUS_KEYS, STATUS, statusLabel, mascaraTelefone,
  fmtTelefone, linkTel, linkWhats, linkMapa, ordenaPorHorario, fmtNumOS, rotuloDia, feriado, debounce,
} from './util.js';
import {
  state, backend, garantirJanela, soltarJanela, janelaPronta, todasOrdens, ordemPorId, garantirMes,
  criarOrdem, editarOrdem, alterarStatus, excluirOrdem, vincularCliente, nomeUsuario, quem,
} from './store.js';
import { ic, cardOS, pillStatus, confirmar, toast, escolherStatus, msgErro } from './ui.js';
import { timelineHtml } from './historico.js';
import { go } from './router.js';

// ================= LISTA / PESQUISA =================
const PRESETS = {
  andamento: { titulo: 'Em andamento', status: ['andamento'], janela: 'p' },
  atrasados: { titulo: 'Atrasados / pendentes de conclusão', status: ['agendado', 'andamento'], ate: () => addDias(hojeISO(), -1), janela: 'p' },
  proximos: { titulo: 'Próximos atendimentos', status: ['agendado', 'andamento'], de: () => addDias(hojeISO(), 1), janela: 'p', ordem: 'asc' },
  concluidoshoje: { titulo: 'Concluídos hoje', status: ['concluido'], janela: 'ch' },
};

export const telaListaOS = {
  titulo: 'Ordens de Serviço', fab: true,
  mount(el, params, q) {
    this.el = el;
    const p = PRESETS[q.get('p')];
    this.f = {
      texto: q.get('q') || '', status: p ? [...p.status] : [...STATUS_KEYS],
      de: p && p.de ? p.de() : (p ? '' : addDias(hojeISO(), -90)), ate: p && p.ate ? p.ate() : '',
      socio: '', ordem: p && p.ordem ? p.ordem : 'desc', preset: q.get('p') || '',
    };
    el.innerHTML = `
      ${p ? `<div class="preset-cab"><b>${esc(p.titulo)}</b><a class="link" href="#/os">Limpar filtro</a></div>` : ''}
      <div class="busca">${ic('search')}<input type="search" data-f="texto" placeholder="Nº da OS, cliente, telefone, placa, veículo, serviço…" value="${esc(this.f.texto)}" autocomplete="off"></div>
      <details class="filtros" ${p ? '' : ''}>
        <summary>${ic('filter')} Filtros <span data-resumo-filtro class="muted"></span></summary>
        <div class="filtros-corpo">
          <div class="campo"><span class="rot">Status</span><div class="chips">
            ${STATUS_KEYS.map((s) => `<label class="chip chk st-${s}"><input type="checkbox" data-st="${s}" ${this.f.status.includes(s) ? 'checked' : ''}><span class="dot st-${s}"></span>${STATUS[s].label}</label>`).join('')}
          </div></div>
          <div class="campo"><span class="rot">Período (data do atendimento)</span>
            <div class="linha2"><input type="date" data-f="de" value="${this.f.de}" aria-label="De"><input type="date" data-f="ate" value="${this.f.ate}" aria-label="Até"></div>
            <div class="chips mt-s">
              <button class="chip" data-per="90">Últimos 90 dias + futuros</button>
              <button class="chip" data-per="mes">Este mês</button>
              <button class="chip" data-per="tudo">Todo o período</button>
            </div></div>
          <div class="linha2">
            <label class="campo"><span class="rot">Lançado por</span><select data-f="socio"><option value="">Todos</option>
              ${Object.values(state.usuarios).map((u) => `<option value="${esc(u.id)}">${esc(u.nome || u.email)}</option>`).join('')}</select></label>
            <label class="campo"><span class="rot">Ordenar</span><select data-f="ordem">
              <option value="desc" ${this.f.ordem === 'desc' ? 'selected' : ''}>Data: mais recentes</option>
              <option value="asc" ${this.f.ordem === 'asc' ? 'selected' : ''}>Data: mais antigas</option>
              <option value="num" ${this.f.ordem === 'num' ? 'selected' : ''}>Número da OS</option></select></label>
          </div>
        </div>
      </details>
      <div data-res></div>`;
    const atualiza = () => { this.assinar(); this.update(); };
    el.querySelector('[data-f="texto"]').oninput = debounce((e) => { this.f.texto = e.target.value; this.update(); }, 150);
    el.querySelectorAll('[data-st]').forEach((c) => (c.onchange = () => { this.f.status = [...el.querySelectorAll('[data-st]:checked')].map((x) => x.dataset.st); this.f.preset = ''; atualiza(); }));
    ['de', 'ate'].forEach((k) => (el.querySelector(`[data-f="${k}"]`).onchange = (e) => { this.f[k] = e.target.value; this.f.preset = ''; atualiza(); }));
    ['socio', 'ordem'].forEach((k) => (el.querySelector(`[data-f="${k}"]`).onchange = (e) => { this.f[k] = e.target.value; this.update(); }));
    el.querySelectorAll('[data-per]').forEach((b) => (b.onclick = () => {
      const h = hojeISO();
      if (b.dataset.per === '90') { this.f.de = addDias(h, -90); this.f.ate = ''; }
      if (b.dataset.per === 'mes') { this.f.de = h.slice(0, 7) + '-01'; this.f.ate = addDias(addDias(h.slice(0, 7) + '-01', 31).slice(0, 7) + '-01', -1); }
      if (b.dataset.per === 'tudo') { this.f.de = ''; this.f.ate = ''; }
      el.querySelector('[data-f="de"]').value = this.f.de; el.querySelector('[data-f="ate"]').value = this.f.ate;
      this.f.preset = ''; atualiza();
    }));
    this.assinar(); this.update();
  },
  assinar() {
    const p = PRESETS[this.f.preset];
    let key;
    if (p) key = p.janela;
    else if (this.f.status.length && this.f.status.every((s) => s !== 'concluido') && !this.f.de) key = 'p';
    else {
      key = `l:${this.f.de}|${this.f.ate}`;
      garantirJanela(key, { from: this.f.de || null, to: this.f.ate || null });
    }
    if (this.key && this.key !== key && this.key.startsWith('l:')) soltarJanela(this.key);
    this.key = key;
  },
  unmount() { if (this.key && this.key.startsWith('l:')) soltarJanela(this.key); },
  filtrar() {
    const f = this.f; const t = normaliza(f.texto); const td = soDigitos(f.texto);
    let l = todasOrdens().filter((o) => f.status.includes(o.status)
      && (!f.de || o.data >= f.de) && (!f.ate || o.data <= f.ate)
      && (!f.socio || (o.criadoPor && quem(o.criadoPor) === f.socio)));
    if (f.preset === 'concluidoshoje') { const i = new Date(); i.setHours(0, 0, 0, 0); l = l.filter((o) => o.concluidoEm >= i.getTime()); }
    if (t) {
      l = l.filter((o) => {
        const alvo = normaliza([o.clienteNome, o.veiculo, o.placa, o.descricao, o.observacoes, o.endereco].join(' '));
        if (alvo.includes(t)) return true;
        if (td && (String(o.numero) === String(Number(td)) || fmtNumOS(o.numero).includes(td))) return true;
        if (td.length >= 3 && soDigitos(o.telefone).includes(td)) return true;
        if (normaliza(o.placa).replace(/[^a-z0-9]/g, '').includes(t.replace(/[^a-z0-9]/g, '')) && t.replace(/[^a-z0-9]/g, '').length >= 3) return true;
        return false;
      });
    }
    if (f.ordem === 'num') l.sort((a, b) => b.numero - a.numero);
    else if (f.ordem === 'asc') l.sort(ordenaPorHorario);
    else l.sort((a, b) => -ordenaPorHorario(a, b));
    return l;
  },
  update() {
    const res = this.el.querySelector('[data-res]');
    const rf = this.el.querySelector('[data-resumo-filtro]');
    const f = this.f;
    rf.textContent = `· ${f.status.length === 3 ? 'todos os status' : f.status.map(statusLabel).join(', ') || 'nenhum status'} · ${f.de || f.ate ? `${f.de ? fmtData(f.de) : 'início'} a ${f.ate ? fmtData(f.ate) : 'futuro'}` : 'todo o período'}`;
    if (!janelaPronta(this.key)) { res.innerHTML = '<div class="carregando">Carregando…</div>'; return; }
    const l = this.filtrar();
    const lim = this.limite || 100;
    res.innerHTML = `<p class="muted cont">${l.length} ordem(ns) de serviço encontrada(s)</p>
      ${l.length ? `<div class="lista">${l.slice(0, lim).map((o) => cardOS(o, { mostrarData: true })).join('')}</div>` : '<div class="vazio">Nenhuma OS encontrada com esses filtros.</div>'}
      ${l.length > lim ? `<button class="btn btn-sec bloco mt" data-mais>Mostrar mais (${l.length - lim})</button>` : ''}`;
    const m = res.querySelector('[data-mais]'); if (m) m.onclick = () => { this.limite = lim + 100; this.update(); };
  },
};

// ================= FORMULÁRIO (nova / editar / duplicar) =================
export const telaFormOS = {
  titulo: 'Nova OS', voltar: true, estatico: true,
  async mount(el, params, q) {
    this.el = el; this.modo = params.modo; this.antes = null;
    let v = { clienteId: null, clienteNome: '', telefone: '', veiculo: '', placa: '', descricao: '', endereco: '', data: q.get('d') || hojeISO(), hora: '', status: 'agendado', observacoes: '' };
    if (this.modo === 'editar' || this.modo === 'duplicar') {
      el.innerHTML = '<div class="carregando">Carregando…</div>';
      const o = ordemPorId(params.id) || await backend.getOrdem(params.id);
      if (!o) { el.innerHTML = '<div class="vazio">OS não encontrada.</div>'; return; }
      if (this.modo === 'editar') { this.antes = o; v = { ...v, ...o }; this.titulo = `Editar OS ${fmtNumOS(o.numero)}`; }
      else { v = { ...v, ...o, data: q.get('d') || hojeISO(), status: 'agendado' }; this.origem = o; this.titulo = 'Duplicar OS'; }
    } else this.titulo = 'Nova Ordem de Serviço';
    document.querySelector('[data-titulo]').textContent = this.titulo;
    this.v = v;
    const h = hojeISO();
    el.innerHTML = `
      <form class="form" novalidate>
        ${this.modo === 'duplicar' ? `<div class="aviso">${ic('copy')} Cópia da OS ${fmtNumOS(this.origem.numero)}. Ajuste a data e salve para gerar uma nova OS.</div>` : ''}
        ${this.antes ? `<div class="aviso neutro">OS nº <b>${fmtNumOS(this.antes.numero)}</b> · criada por ${esc(nomeUsuario(this.antes.criadoPor))} em ${esc(fmtMs(this.antes.criadoEm))}</div>`
          : `<div class="aviso neutro">O número da OS será gerado automaticamente ao salvar.</div>`}
        <label class="campo req"><span class="rot">Nome do cliente *</span>
          <div class="ac"><input name="clienteNome" required autocomplete="off" value="${esc(v.clienteNome)}" placeholder="Digite para buscar ou cadastrar">
          <div class="ac-lista" hidden></div></div>
          <small class="dica" data-cli-info>${v.clienteId ? '✓ Cliente cadastrado' : ''}</small></label>
        <label class="campo"><span class="rot">Telefone / WhatsApp</span>
          <input name="telefone" type="tel" inputmode="tel" value="${esc(mascaraTelefone(v.telefone))}" placeholder="(00) 00000-0000"></label>
        <div class="linha2">
          <label class="campo"><span class="rot">Veículo / máquina</span><input name="veiculo" value="${esc(v.veiculo)}" placeholder="Ex.: Caminhão Volvo FH" list="dl-veiculos"></label>
          <label class="campo"><span class="rot">Placa</span><input name="placa" value="${esc(v.placa)}" placeholder="Opcional" autocapitalize="characters" class="maiusc"></label>
        </div>
        <datalist id="dl-veiculos"></datalist>
        <label class="campo"><span class="rot">Descrição do serviço</span><textarea name="descricao" rows="3" placeholder="Serviço a ser realizado">${esc(v.descricao)}</textarea></label>
        <div class="campo req"><span class="rot">Data do atendimento *</span>
          <input name="data" type="date" required value="${esc(v.data)}">
          <div class="chips mt-s">
            <button type="button" class="chip" data-dt="${h}">Hoje</button>
            <button type="button" class="chip" data-dt="${addDias(h, 1)}">Amanhã</button>
            <button type="button" class="chip" data-dt="${addDias(h, 2)}">${esc(rotuloDia(addDias(h, 2)))}</button>
          </div><small class="dica" data-dt-info></small></div>
        <div class="campo"><span class="rot">Horário (opcional)</span>
          <div class="linha-hora"><input name="hora" type="time" value="${esc(v.hora)}"><button type="button" class="chip" data-sem-hora>Sem horário</button></div></div>
        <div class="campo req"><span class="rot">Status *</span>
          <div class="seg seg-status">${STATUS_KEYS.map((s) => `<label class="seg-b st-${s} ${v.status === s ? 'on' : ''}"><input type="radio" name="status" value="${s}" ${v.status === s ? 'checked' : ''}><span class="dot st-${s}"></span>${STATUS[s].label}</label>`).join('')}</div></div>
        <details class="mais" ${v.endereco || v.observacoes ? 'open' : ''}><summary>Observações e endereço</summary>
          <label class="campo"><span class="rot">Observações</span><textarea name="observacoes" rows="3">${esc(v.observacoes)}</textarea></label>
          <label class="campo"><span class="rot">Endereço / local do atendimento</span><input name="endereco" value="${esc(v.endereco)}" placeholder="Opcional — habilita o botão de mapa"></label>
        </details>
        <p class="muted peq">Responsável pelo lançamento: <b>${esc(state.me ? state.me.nome : '')}</b></p>
        <div class="form-rodape"><button type="button" class="btn btn-sec" data-cancelar>Cancelar</button>
          <button type="submit" class="btn btn-pri" data-salvar>${ic('check')} Salvar OS</button></div>
      </form>`;
    this.ligar();
    if (q.get('cliente') && this.modo === 'nova') this.selCliente(q.get('cliente'));
  },
  ligar() {
    const f = this.el.querySelector('form'); const el = this.el;
    const nomeI = f.clienteNome; const acL = el.querySelector('.ac-lista'); const info = el.querySelector('[data-cli-info]');
    const mostrarSug = () => {
      const t = normaliza(nomeI.value);
      const sug = t ? state.clientes.filter((c) => normaliza(c.nome).includes(t) || (soDigitos(nomeI.value).length >= 3 && soDigitos(c.telefone).includes(soDigitos(nomeI.value)))).slice(0, 6) : [];
      if (!sug.length || document.activeElement !== nomeI) { acL.hidden = true; return; }
      acL.innerHTML = sug.map((c) => `<button type="button" data-cli="${esc(c.id)}"><b>${esc(c.nome)}</b>${c.telefone ? `<small>${esc(fmtTelefone(c.telefone))}</small>` : ''}</button>`).join('');
      acL.hidden = false;
      acL.querySelectorAll('[data-cli]').forEach((b) => (b.onpointerdown = (e) => { e.preventDefault(); this.selCliente(b.dataset.cli); }));
    };
    nomeI.oninput = () => {
      const c = this.v.clienteId && state.clientes.find((x) => x.id === this.v.clienteId);
      if (c && normaliza(c.nome) !== normaliza(nomeI.value)) { this.v.clienteId = null; info.textContent = ''; }
      mostrarSug();
    };
    nomeI.onfocus = mostrarSug;
    nomeI.onblur = () => setTimeout(() => (acL.hidden = true), 150);
    f.telefone.oninput = () => { f.telefone.value = mascaraTelefone(f.telefone.value); };
    f.placa.oninput = () => { const p = f.placa.selectionStart; f.placa.value = f.placa.value.toUpperCase(); f.placa.setSelectionRange(p, p); };
    const dtInfo = () => {
      const d = f.data.value; const i = el.querySelector('[data-dt-info]');
      if (!d) { i.textContent = ''; return; }
      const fer = feriado(d); const dow = new Date(d + 'T12:00').getDay();
      i.textContent = [rotuloDia(d), fer ? `feriado: ${fer}` : '', dow === 0 ? 'domingo' : dow === 6 ? 'sábado' : ''].filter(Boolean).join(' · ');
    };
    f.data.onchange = dtInfo; dtInfo();
    el.querySelectorAll('[data-dt]').forEach((b) => (b.onclick = () => { f.data.value = b.dataset.dt; dtInfo(); }));
    el.querySelector('[data-sem-hora]').onclick = () => { f.hora.value = ''; };
    el.querySelectorAll('input[name="status"]').forEach((r) => (r.onchange = () => el.querySelectorAll('.seg-status .seg-b').forEach((l) => l.classList.toggle('on', l.querySelector('input').checked))));
    el.querySelector('[data-cancelar]').onclick = () => history.back();
    f.onsubmit = (e) => { e.preventDefault(); this.salvar(); };
    if (this.v.clienteId) this.preencherVeiculos(this.v.clienteId);
    if (!this.antes && !nomeI.value) setTimeout(() => { if (!el.contains(document.activeElement) || document.activeElement === document.body) nomeI.focus(); }, 50);
  },
  selCliente(id) {
    const c = state.clientes.find((x) => x.id === id); if (!c) return;
    const f = this.el.querySelector('form');
    this.v.clienteId = c.id; f.clienteNome.value = c.nome;
    if (c.telefone) f.telefone.value = mascaraTelefone(c.telefone);
    if (c.endereco && !f.endereco.value) f.endereco.value = c.endereco;
    this.el.querySelector('[data-cli-info]').textContent = '✓ Cliente cadastrado — telefone preenchido';
    this.el.querySelector('.ac-lista').hidden = true;
    this.preencherVeiculos(c.id);
    f.veiculo.focus();
  },
  async preencherVeiculos(clienteId) {
    try {
      const l = await backend.getOrdens({ clienteId });
      const dl = this.el.querySelector('#dl-veiculos');
      const vs = [...new Set(l.map((o) => [o.veiculo, o.placa].filter(Boolean).join(' — ')).filter(Boolean))].slice(0, 10);
      dl.innerHTML = [...new Set(l.map((o) => o.veiculo).filter(Boolean))].map((v) => `<option value="${esc(v)}">`).join('');
      if (vs.length && !this.el.querySelector('form').veiculo.value) this.el.querySelector('[data-cli-info]').textContent += ` · veículos anteriores: ${vs.slice(0, 3).join('; ')}`;
    } catch {}
  },
  async salvar() {
    const f = this.el.querySelector('form'); const btn = this.el.querySelector('[data-salvar]');
    const campos = {
      clienteId: this.v.clienteId, clienteNome: f.clienteNome.value, telefone: f.telefone.value, veiculo: f.veiculo.value, placa: f.placa.value,
      descricao: f.descricao.value, endereco: f.endereco.value, data: f.data.value, hora: f.hora.value,
      status: (f.querySelector('input[name="status"]:checked') || {}).value, observacoes: f.observacoes.value,
    };
    f.querySelectorAll('.erro').forEach((x) => x.classList.remove('erro'));
    const faltando = [];
    if (!campos.clienteNome.trim()) { faltando.push('nome do cliente'); f.clienteNome.closest('.campo').classList.add('erro'); }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(campos.data)) { faltando.push('data'); f.data.closest('.campo').classList.add('erro'); }
    if (!campos.status) faltando.push('status');
    if (faltando.length) { toast('Preencha: ' + faltando.join(', '), 'erro'); return; }
    btn.disabled = true; btn.textContent = 'Salvando…';
    try {
      campos.clienteId = await vincularCliente(campos, (c) => confirmar('Cliente já cadastrado',
        `Já existe o cliente <b>${esc(c.nome)}</b> com este telefone. Deseja usar esse cadastro?`, { ok: 'Usar cadastro existente', cancelar: 'Cadastrar novo' }));
      if (this.antes) {
        const atual = ordemPorId(this.antes.id) || this.antes;
        const mudou = await editarOrdem(atual, campos);
        toast(mudou ? 'Alterações salvas' : 'Nenhuma alteração');
        go(`#/os/${this.antes.id}`, true);
      } else {
        const r = await criarOrdem(campos, this.origem ? `Duplicada da OS ${fmtNumOS(this.origem.numero)}` : '');
        toast(`OS ${fmtNumOS(r.numero)} criada`);
        garantirMes(campos.data.slice(0, 7));
        go(`#/os/${r.id}`, true);
      }
    } catch (e) {
      console.error(e); toast(msgErro(e), 'erro');
      btn.disabled = false; btn.innerHTML = `${ic('check')} Salvar OS`;
    }
  },
};

// ================= FICHA DA OS =================
export const telaDetalheOS = {
  titulo: 'Ordem de Serviço', voltar: true,
  async mount(el, params) {
    this.el = el; this.id = params.id; this.hist = []; this.buscou = false;
    el.innerHTML = '<div class="carregando">Carregando…</div>';
    this.unsubH = backend.watchHistorico({ osId: this.id }, (l) => { this.hist = l.sort((a, b) => (a.em || 0) - (b.em || 0)); this.update(); });
    let o = ordemPorId(this.id);
    if (!o) { o = await backend.getOrdem(this.id).catch(() => null); }
    this.buscou = true; this.reserva = o;
    if (o) garantirMes(o.data.slice(0, 7));
    this.update();
  },
  unmount() { this.unsubH && this.unsubH(); },
  update() {
    if (!this.buscou) return;
    let o = ordemPorId(this.id);
    if (!o && this.reserva) {
      const mes = 'm:' + this.reserva.data.slice(0, 7);
      if (!janelaPronta(mes)) o = this.reserva;
      else if (!this.rebuscando && (this.nRebusca = (this.nRebusca || 0) + 1) <= 3) {
        // pode ter mudado de data (outro mês): busca de novo
        this.rebuscando = true;
        backend.getOrdem(this.id).then((n) => { this.reserva = n; if (n) garantirMes(n.data.slice(0, 7)); this.rebuscando = false; this.update(); }).catch(() => {});
        o = this.reserva;
      } else o = this.reserva;
    }
    if (!o) {
      this.el.innerHTML = `<div class="vazio">Esta OS não foi encontrada ou foi excluída.</div>
        ${this.hist.length ? `<h3 class="sec-titulo">Histórico</h3>${timelineHtml(this.hist)}` : ''}`;
      return;
    }
    document.querySelector('[data-titulo]').textContent = `OS ${fmtNumOS(o.numero)}`;
    const tel = linkTel(o.telefone); const wa = linkWhats(o.telefone); const mapa = linkMapa(o.endereco);
    const fer = feriado(o.data);
    this.el.innerHTML = `
      <div class="ficha-cab st-fundo-${esc(o.status)}">
        <div><small>OS nº</small><div class="ficha-num">${fmtNumOS(o.numero)}</div></div>
        ${pillStatus(o.status, 'grande')}
      </div>
      <div class="seg seg-status ficha-status">${STATUS_KEYS.map((s) => `<button class="seg-b st-${s} ${o.status === s ? 'on' : ''}" data-mudar="${s}"><span class="dot st-${s}"></span>${STATUS[s].label}</button>`).join('')}</div>
      <div class="acoes-rapidas">
        ${tel ? `<a class="acao" href="${esc(tel)}">${ic('phone')}<span>Ligar</span></a>` : `<span class="acao off">${ic('phone')}<span>Ligar</span></span>`}
        ${wa ? `<a class="acao wa" href="${esc(wa)}" target="_blank" rel="noopener">${ic('whats')}<span>WhatsApp</span></a>` : `<span class="acao off">${ic('whats')}<span>WhatsApp</span></span>`}
        ${mapa ? `<a class="acao" href="${esc(mapa)}" target="_blank" rel="noopener">${ic('map')}<span>Mapa</span></a>` : `<span class="acao off" title="Cadastre o endereço para usar">${ic('map')}<span>Mapa</span></span>`}
      </div>
      <dl class="ficha">
        <div><dt>Cliente</dt><dd>${o.clienteId ? `<a href="#/clientes/${esc(o.clienteId)}">${esc(o.clienteNome)}</a>` : esc(o.clienteNome)}</dd></div>
        <div><dt>Telefone</dt><dd>${tel ? `<a href="${esc(tel)}">${esc(fmtTelefone(o.telefone))}</a>` : '—'}</dd></div>
        <div><dt>Veículo / máquina</dt><dd>${esc(o.veiculo) || '—'}</dd></div>
        <div><dt>Placa</dt><dd>${o.placa ? `<span class="placa">${esc(o.placa)}</span>` : '—'}</dd></div>
        <div class="full"><dt>Serviço</dt><dd class="pre">${esc(o.descricao) || '—'}</dd></div>
        <div><dt>Data</dt><dd><a href="#/agenda?v=dia&d=${esc(o.data)}">${esc(fmtData(o.data))}</a> <small class="muted">${esc(rotuloDia(o.data))}${fer ? ' · ' + esc(fer) : ''}</small></dd></div>
        <div><dt>Horário</dt><dd>${esc(o.hora) || 'Sem horário definido'}</dd></div>
        ${o.endereco ? `<div class="full"><dt>Endereço / local</dt><dd>${esc(o.endereco)}</dd></div>` : ''}
        <div class="full"><dt>Observações</dt><dd class="pre">${esc(o.observacoes) || '—'}</dd></div>
      </dl>
      <dl class="ficha meta">
        <div><dt>Cadastrada por</dt><dd>${esc(nomeUsuario(o.criadoPor))}</dd></div>
        <div><dt>Data/hora do cadastro</dt><dd>${esc(fmtMs(o.criadoEm))}</dd></div>
        <div><dt>Status alterado por</dt><dd>${esc(nomeUsuario(o.statusPor))} · ${esc(fmtMs(o.statusEm))}</dd></div>
        <div><dt>Última alteração</dt><dd>${esc(nomeUsuario(o.atualizadoPor))} · ${esc(fmtMs(o.atualizadoEm))}</dd></div>
        ${o.status === 'concluido' ? `<div class="full concl"><dt>Concluída</dt><dd>${esc(fmtMs(o.concluidoEm))} por ${esc(nomeUsuario(o.concluidoPor))}</dd></div>` : ''}
        ${o._pendente ? '<div class="full"><dd class="muted">⟳ Alterações aguardando sincronização (sem internet).</dd></div>' : ''}
      </dl>
      <div class="botoes-ficha">
        <a class="btn btn-sec" href="#/os/${esc(o.id)}/editar">${ic('edit')} Editar</a>
        <a class="btn btn-sec" href="#/os/${esc(o.id)}/duplicar">${ic('copy')} Duplicar</a>
        <button class="btn btn-perigo-sec" data-excluir>${ic('trash')} Excluir</button>
      </div>
      <h3 class="sec-titulo" id="historico">${ic('hist')} Histórico de alterações</h3>
      ${timelineHtml(this.hist)}`;
    this.el.querySelectorAll('[data-mudar]').forEach((b) => (b.onclick = async () => {
      const novo = b.dataset.mudar; if (novo === o.status) return;
      try { await alterarStatus(o, novo); toast(`Status: ${statusLabel(novo)}`); } catch (e) { toast(msgErro(e), 'erro'); }
    }));
    this.el.querySelector('[data-excluir]').onclick = async () => {
      const ok = await confirmar('Excluir OS?', `A OS <b>${fmtNumOS(o.numero)}</b> de <b>${esc(o.clienteNome)}</b> será excluída. O histórico de auditoria (incluindo uma cópia dos dados) será mantido.`, { ok: 'Excluir', perigo: true });
      if (!ok) return;
      try { await excluirOrdem(o); toast('OS excluída'); go('#/os', true); } catch (e) { toast(msgErro(e), 'erro'); }
    };
  },
};

// Ação global: alterar status a partir de qualquer cartão
export async function acaoStatusCartao(id) {
  const o = ordemPorId(id) || await backend.getOrdem(id);
  if (!o) return;
  const novo = await escolherStatus(o.status);
  if (!novo || novo === o.status) return;
  try { await alterarStatus(o, novo); toast(`OS ${fmtNumOS(o.numero)}: ${statusLabel(novo)}`); } catch (e) { toast(msgErro(e), 'erro'); }
}
