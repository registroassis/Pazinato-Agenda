// Tela: Relatórios (visualizar, PDF, Excel, imprimir).
import { esc, hojeISO, fmtData, fmtMs, MESES, ultimoDiaMes, STATUS_KEYS, STATUS, statusLabel, ordenaPorHorario, fmtTelefone, fmtNumOS, addDias, parseISO, DIAS_CURTO } from './util.js';
import { state, backend, nomeUsuario, quem } from './store.js';
import { ic, toast, msgErro } from './ui.js';

const TIPOS = {
  periodo: 'Serviços por período',
  agendados: 'Serviços agendados',
  andamento: 'Serviços em andamento',
  concluidos: 'Serviços concluídos',
  socio: 'Relatório por sócio',
  mensal: 'Resumo mensal',
};

export const telaRelatorios = {
  titulo: 'Relatórios', estatico: true,
  mount(el) {
    this.el = el;
    const h = hojeISO(); const ano = Number(h.slice(0, 4));
    el.innerHTML = `
      <form class="form rel-form" novalidate>
        <label class="campo"><span class="rot">Relatório</span><select name="tipo">${Object.entries(TIPOS).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></label>
        <div class="campo" data-bloco-periodo><span class="rot">Período</span>
          <div class="seg">${[['intervalo', 'Intervalo'], ['dia', 'Dia'], ['mes', 'Mês'], ['ano', 'Ano'], ['tudo', 'Tudo']].map(([k, l]) => `<label class="seg-b ${k === 'mes' ? 'on' : ''}"><input type="radio" name="modo" value="${k}" ${k === 'mes' ? 'checked' : ''}>${l}</label>`).join('')}</div>
          <div class="mt-s" data-modo="intervalo" hidden><div class="linha2"><label><small>Data inicial</small><input type="date" name="de" value="${h.slice(0, 7)}-01"></label><label><small>Data final</small><input type="date" name="ate" value="${ultimoDiaMes(h.slice(0, 7))}"></label></div></div>
          <div class="mt-s" data-modo="dia" hidden><input type="date" name="dia" value="${h}"></div>
          <div class="mt-s" data-modo="mes"><div class="linha2"><select name="mes">${MESES.map((m, i) => `<option value="${i + 1}" ${i + 1 === Number(h.slice(5, 7)) ? 'selected' : ''}>${m}</option>`).join('')}</select>
            <input type="number" name="anoMes" value="${ano}" min="2000" max="2100" inputmode="numeric"></div></div>
          <div class="mt-s" data-modo="ano" hidden><input type="number" name="ano" value="${ano}" min="2000" max="2100" inputmode="numeric"></div>
        </div>
        <div class="linha2">
          <label class="campo" data-bloco-status><span class="rot">Status</span><select name="status"><option value="">Todos</option>${STATUS_KEYS.map((s) => `<option value="${s}">${STATUS[s].label}</option>`).join('')}</select></label>
          <label class="campo"><span class="rot">Sócio (lançamento)</span><select name="socio"><option value="">Todos</option>${Object.values(state.usuarios).map((u) => `<option value="${esc(u.id)}">${esc(u.nome || u.email)}</option>`).join('')}</select></label>
        </div>
        <label class="campo"><span class="rot">Cliente</span><select name="cliente"><option value="">Todos</option>${state.clientes.map((c) => `<option value="${esc(c.id)}">${esc(c.nome)}</option>`).join('')}</select></label>
        <button class="btn btn-pri bloco" type="submit">${ic('rel')} Gerar relatório</button>
      </form>
      <div data-res></div>`;
    const f = el.querySelector('form');
    const ajusta = () => {
      const tipo = f.tipo.value;
      if (tipo === 'mensal') { f.querySelector('input[name="modo"][value="mes"]').checked = true; }
      const modo = f.querySelector('input[name="modo"]:checked').value;
      f.querySelectorAll('input[name="modo"]').forEach((r) => { r.closest('.seg-b').classList.toggle('on', r.checked); r.disabled = tipo === 'mensal' && r.value !== 'mes'; r.closest('.seg-b').classList.toggle('off', r.disabled); });
      f.querySelectorAll('[data-modo]').forEach((b) => (b.hidden = b.dataset.modo !== modo));
      f.querySelector('[data-bloco-status]').hidden = ['agendados', 'andamento', 'concluidos'].includes(tipo);
    };
    f.tipo.onchange = ajusta; f.querySelectorAll('input[name="modo"]').forEach((r) => (r.onchange = ajusta)); ajusta();
    f.onsubmit = (e) => { e.preventDefault(); this.gerar(); };
  },
  lerFiltros() {
    const f = this.el.querySelector('form'); const modo = f.querySelector('input[name="modo"]:checked').value;
    let de = null, ate = null, periodoTxt = 'Todo o período';
    if (modo === 'intervalo') { de = f.de.value; ate = f.ate.value; if (!de || !ate || de > ate) throw new Error('Informe um intervalo válido.'); periodoTxt = `${fmtData(de)} a ${fmtData(ate)}`; }
    if (modo === 'dia') { de = ate = f.dia.value; if (!de) throw new Error('Informe o dia.'); periodoTxt = fmtData(de); }
    if (modo === 'mes') { const ym = `${f.anoMes.value}-${String(f.mes.value).padStart(2, '0')}`; if (!/^\d{4}-\d{2}$/.test(ym)) throw new Error('Ano inválido.'); de = ym + '-01'; ate = ultimoDiaMes(ym); periodoTxt = `${MESES[Number(f.mes.value) - 1]} de ${f.anoMes.value}`; }
    if (modo === 'ano') { if (!/^\d{4}$/.test(f.ano.value)) throw new Error('Ano inválido.'); de = `${f.ano.value}-01-01`; ate = `${f.ano.value}-12-31`; periodoTxt = `Ano de ${f.ano.value}`; }
    return { tipo: f.tipo.value, modo, de, ate, periodoTxt, status: f.status.value, socio: f.socio.value, cliente: f.cliente.value };
  },
  async gerar() {
    const res = this.el.querySelector('[data-res]');
    let F; try { F = this.lerFiltros(); } catch (e) { toast(e.message, 'erro'); return; }
    res.innerHTML = '<div class="carregando">Gerando relatório…</div>';
    try {
      let lista = F.tipo === 'andamento' && !F.de ? await backend.getOrdens({ pendentes: true }) : await backend.getOrdens(F.de ? { from: F.de, to: F.ate } : {});
      const st = { agendados: 'agendado', andamento: 'andamento', concluidos: 'concluido' }[F.tipo] || F.status;
      if (st) lista = lista.filter((o) => o.status === st);
      if (F.cliente) lista = lista.filter((o) => o.clienteId === F.cliente);
      if (F.socio && F.tipo !== 'socio') lista = lista.filter((o) => o.criadoPor && quem(o.criadoPor) === F.socio);
      lista.sort(ordenaPorHorario);
      this.rel = montarRelatorio(F, lista, st);
      res.innerHTML = previewHtml(this.rel);
      res.querySelector('[data-pdf]').onclick = () => this.exportar('pdf');
      res.querySelector('[data-xlsx]').onclick = () => this.exportar('xlsx');
      res.querySelector('[data-print]').onclick = () => import('./export.js').then((m) => m.imprimir(this.rel));
      res.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (e) { console.error(e); res.innerHTML = `<div class="vazio">${esc(msgErro(e))}</div>`; }
  },
  async exportar(tipo) {
    const b = this.el.querySelector(tipo === 'pdf' ? '[data-pdf]' : '[data-xlsx]'); const txt = b.innerHTML;
    b.disabled = true; b.textContent = 'Gerando…';
    try { const m = await import('./export.js'); await (tipo === 'pdf' ? m.gerarPDF(this.rel) : m.gerarXLSX(this.rel)); }
    catch (e) { console.error(e); toast('Falha ao exportar: ' + msgErro(e), 'erro'); }
    finally { b.disabled = false; b.innerHTML = txt; }
  },
};

const COLS = ['OS', 'Data', 'Horário', 'Cliente', 'Telefone', 'Veículo/máquina', 'Placa', 'Serviço', 'Status', 'Lançado por', 'Conclusão'];
function linhaOS(o) {
  return [fmtNumOS(o.numero), fmtData(o.data), o.hora || '—', o.clienteNome, fmtTelefone(o.telefone) || '', o.veiculo || '', o.placa || '', o.descricao || '',
    statusLabel(o.status), nomeUsuario(o.criadoPor), o.status === 'concluido' ? `${fmtMs(o.concluidoEm)} (${nomeUsuario(o.concluidoPor)})` : ''];
}
function contar(lista) { return Object.fromEntries(STATUS_KEYS.map((s) => [s, lista.filter((o) => o.status === s).length])); }

function montarRelatorio(F, lista, stFixo) {
  const filtros = [];
  if (stFixo && !['agendados', 'andamento', 'concluidos'].includes(F.tipo)) filtros.push(`Status: ${statusLabel(stFixo)}`);
  if (F.cliente) filtros.push(`Cliente: ${(state.clientes.find((c) => c.id === F.cliente) || {}).nome || ''}`);
  if (F.socio) filtros.push(`${F.tipo === 'socio' ? 'Sócio' : 'Lançado por'}: ${(state.usuarios[F.socio] || {}).nome || ''}`);
  const c = contar(lista);
  const rel = {
    titulo: TIPOS[F.tipo], tipo: F.tipo, periodo: F.periodoTxt, filtros: filtros.length ? filtros.join(' · ') : 'Nenhum filtro adicional',
    emitidoEm: fmtMs(Date.now()), emitidoPor: state.me ? state.me.nome : '',
    resumo: [['Total de serviços', lista.length], ['Agendados', c.agendado], ['Em andamento', c.andamento], ['Concluídos', c.concluido]],
    secoes: [],
  };
  if (F.tipo === 'socio') {
    const socios = Object.values(state.usuarios).filter((u) => !F.socio || u.id === F.socio);
    rel.resumo = [['Total de serviços no período', lista.length]];
    for (const u of socios) {
      const part = lista.filter((o) => [o.criadoPor, o.atualizadoPor, o.concluidoPor, o.statusPor].some((x) => x && quem(x) === u.id));
      const criou = lista.filter((o) => o.criadoPor && quem(o.criadoPor) === u.id).length;
      const concluiu = lista.filter((o) => o.status === 'concluido' && o.concluidoPor && quem(o.concluidoPor) === u.id).length;
      rel.resumo.push([`${u.nome || u.email}: cadastrou / concluiu`, `${criou} / ${concluiu}`]);
      rel.secoes.push({
        titulo: `${u.nome || u.email} — ${part.length} serviço(s) cadastrados ou atualizados`,
        colunas: ['OS', 'Data', 'Cliente', 'Veículo/máquina', 'Serviço', 'Status', 'Participação'],
        linhas: part.map((o) => {
          const p = []; if (o.criadoPor && quem(o.criadoPor) === u.id) p.push('Cadastrou');
          if (o.status === 'concluido' && o.concluidoPor && quem(o.concluidoPor) === u.id) p.push('Concluiu');
          else if (o.statusPor && quem(o.statusPor) === u.id && !(o.criadoPor && quem(o.criadoPor) === u.id)) p.push('Alterou status');
          if (o.atualizadoPor && quem(o.atualizadoPor) === u.id && !p.length) p.push('Atualizou');
          return [fmtNumOS(o.numero), fmtData(o.data), o.clienteNome, [o.veiculo, o.placa].filter(Boolean).join(' · '), o.descricao || '', statusLabel(o.status), p.join(', ')];
        }),
      });
    }
  } else if (F.tipo === 'mensal') {
    const dias = {};
    for (const o of lista) { dias[o.data] = dias[o.data] || []; dias[o.data].push(o); }
    rel.secoes.push({
      titulo: 'Serviços por dia', colunas: ['Dia', 'Total', 'Agendado', 'Em andamento', 'Concluído'],
      linhas: Object.keys(dias).sort().map((d) => { const k = contar(dias[d]); return [`${DIAS_CURTO[parseISO(d).getDay()]} ${fmtData(d)}`, dias[d].length, k.agendado, k.andamento, k.concluido]; }),
    });
    rel.secoes.push({
      titulo: 'Por sócio (lançamento)', colunas: ['Sócio', 'Cadastrados', 'Concluídos por ele'],
      linhas: Object.values(state.usuarios).map((u) => [u.nome || u.email, lista.filter((o) => o.criadoPor && quem(o.criadoPor) === u.id).length,
        lista.filter((o) => o.status === 'concluido' && o.concluidoPor && quem(o.concluidoPor) === u.id).length]),
    });
    rel.secoes.push({ titulo: 'Lista de serviços do mês', colunas: COLS, linhas: lista.map(linhaOS) });
  } else {
    rel.secoes.push({ titulo: `${lista.length} serviço(s)`, colunas: COLS, linhas: lista.map(linhaOS) });
  }
  return rel;
}

function previewHtml(rel) {
  return `<section class="rel-preview">
    <div class="rel-cab"><h2>${esc(rel.titulo)}</h2>
      <p><b>Período:</b> ${esc(rel.periodo)}<br><b>Filtros:</b> ${esc(rel.filtros)}<br><small class="muted">Emitido em ${esc(rel.emitidoEm)} por ${esc(rel.emitidoPor)}</small></p></div>
    <div class="rel-botoes">
      <button class="btn btn-pri" data-pdf>${ic('download')} PDF</button>
      <button class="btn btn-sec" data-xlsx>${ic('download')} Excel</button>
      <button class="btn btn-sec" data-print>${ic('print')} Imprimir</button>
    </div>
    <div class="rel-resumo">${rel.resumo.map(([k, v]) => `<div><span>${esc(k)}</span><b>${esc(v)}</b></div>`).join('')}</div>
    ${rel.secoes.map((s) => `<h3 class="sec-titulo">${esc(s.titulo)}</h3>
      ${s.linhas.length ? `<div class="tabela-wrap"><table class="tabela"><thead><tr>${s.colunas.map((c) => `<th>${esc(c)}</th>`).join('')}</tr></thead>
      <tbody>${s.linhas.map((l) => `<tr>${l.map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : '<div class="vazio peq">Nenhum registro.</div>'}`).join('')}
  </section>`;
}
